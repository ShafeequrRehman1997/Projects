package com.cap.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.IUpdateDao;
@Service("UpdateService")
public class UpdateService implements IUpdateService{
	@Autowired
	private IUpdateDao updateDao;
	@Override
	public void delete(Integer productId) {
		updateDao.delete(productId);
	}

}
