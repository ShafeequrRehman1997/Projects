package com.cap.dao;



import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cap.model.Inventory;



@Repository("UpdateDao")
@Transactional
public class UpdateDao implements IUpdateDao{
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public void delete(Integer productId) {
		Inventory product=entityManager.find(Inventory.class, productId);
		entityManager.remove(product);
	}

}
