package com.cap.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cap.model.Inventory;
import com.cap.service.IUpdateService;

@Controller
public class CapController {
	
	@Autowired
	private IUpdateService updateService;
	private Inventory product;
	@RequestMapping("/buyNow")
	public String navigateToShippingDetailsPage() {
		
		return "shippingAddress";
	}
		
	
	@RequestMapping("/addToCart")
	public String navigateToCartPage() {
		
		return "index";
	}
	
	@RequestMapping("/remove")
	public String removeItemFromCart(@PathVariable("productId") Integer productId) {
		updateService.delete(productId);
		return "index";	
	}
	
	@RequestMapping("/CheckOut")
	public String proceedFromCart() {
		return "shippingAddress";	
	}	
	
	@RequestMapping("/ContinueShopping")
	public String continueShopping() {
		return "productPage";
	}
}


//productpage
//has add and buy opt
//buy click ship
//add click index







/*@RequestMapping("/cartpage")
public String proceedNow(ModelMap map) {
	
	return "shippingDetails";
}*/