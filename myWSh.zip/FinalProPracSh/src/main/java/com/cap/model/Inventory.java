package com.cap.model;

import java.util.Date;

public class Inventory {
	private int productId;
	private int stock;
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	@Override
	public String toString() {
		return "Inventory [productId=" + productId + ", stock=" + stock + "]";
	}
	public Inventory(int productId, int stock) {
		super();
		this.productId = productId;
		this.stock = stock;
	}
	public Inventory() {}
}
