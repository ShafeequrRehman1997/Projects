package com.cap.dao;

public interface IUpdateDao  {

}
