
public class PathPages {
	static String url = "file:///P:/Selenium%20workspace/ConferenceRegistration_152770/src/main/webapp/ConferenceRegistration.html";
	static String title = "Conference Registration";
	static String url2 = "file:///P:/Selenium%20workspace/ConferenceRegistration_152770/src/main/webapp/PaymentDetails.html";
	static String title2 = "Payment Details";
	
	public void goTo() {
		Browser.goTo(url);
	}
	
	public void goTo2() {
		Browser.goTo(url2);
	}

	public boolean isAt() {
		return Browser.title().equals(title);
	}
	
	public boolean isAt2() {
		System.out.println(Browser.title());
		return Browser.title().equals(title2);
	}


}
