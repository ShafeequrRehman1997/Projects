import org.junit.Assert;
import org.openqa.selenium.Alert;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class StepDefs {
	
	private ConferenceRegistrationPage page = new ConferenceRegistrationPage();
	@Given("^The participant is on the Conference Registration Page$")
	public void the_participant_is_on_the_Conference_Registration_Page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		page.goTo();
		Assert.assertTrue(page.isAt());
	}

	@When("^He enters the First Name$")
	public void he_enters_the_First_Name() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		page.setFirstName("Ravali");
	}

	@When("^He enters the Last Name$")
	public void he_enters_the_Last_Name() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.setLastName("Kokila");
	}
	
	@When("^He enters the Email$")
	public void he_enters_the_Email() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.setEmail("mkravali09@gmail.com");
	}
	
	@When("^He enters the Contact No$")
	public void he_enters_the_Contact_No() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		page.setPhone("9898989898");
	}

	@When("^He selects the Number of people attending$")
	public void he_selects_the_Number_of_people_attending() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.selectNoOfPeopleAttending();
	}

	@When("^He enters the Building Name & Room No$")
	public void he_enters_the_Building_Name_Room_No() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   page.setAddress1("Vanashree Apts,102");
	}

	@When("^He enters the Area Name$")
	public void he_enters_the_Area_Name() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.setAddress2("Secunderabad");
	}

	@When("^He selects the City$")
	public void he_selects_the_City() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		page.selectCity();
	}

	@When("^He selects the State$")
	public void he_selects_the_State() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.selectState();
	}

	@When("^He selects the Membership status$")
	public void he_selects_the_Membership_status() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   page.selectMembershipStatus();
	}

	@When("^He clicks Next$")
	public void he_clicks_Next() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.clickNext();
	}

	@When("^He is directed to Payment Details page$")
	public void he_is_directed_to_Payment_Details_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		page.accept();
		page.goTo2();

	}

	@When("^check if the title is Personal details$")
	public void check_if_the_title_is_Personal_details() throws Exception {
	    // Write code here that turns the phrase above into concrete actions	
		
		Assert.assertTrue(page.isAt2());
	}

	@When("^He enters the Card Holder Name$")
	public void he_enters_the_Card_Holder_Name() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.setCardholderName("Ravali");
	}

	@When("^He enters the Debit card number$")
	public void he_enters_the_Debit_card_number() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.setDebit("893452345634567");
	}

	@When("^He enters the Card expiration month$")
	public void he_enters_the_Card_expiration_month() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.setMonth("Nov");
	}

	@When("^He enters the Card expiration year$")
	public void he_enters_the_Card_expiration_year() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.setYear("2030");
	}

	@When("^He clicks on Make Payment$")
	public void he_clicks_on_Make_Payment() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.clickMakePayment();
	}

	@Then("^Display Message Conference Room Booking successfully done$")
	public void display_Message_Conference_Room_Booking_successfully_done() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.close();
	}
}
