package com.cap.model;

import java.util.Date;

public class Order {
	private int customerId;
	private int cartId;
	private Date deliveredDate;
	private int orderId;
	private String deliveryStatus;
	private int transactionId;
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public Date getDeliveredDate() {
		return deliveredDate;
	}
	public void setDeliveredDate(Date deliveredDate) {
		this.deliveredDate = deliveredDate;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getDeliveryStatus() {
		return deliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	@Override
	public String toString() {
		return "Order [customerId=" + customerId + ", cartId=" + cartId + ", deliveredDate=" + deliveredDate
				+ ", orderId=" + orderId + ", deliveryStatus=" + deliveryStatus + ", transactionId=" + transactionId
				+ "]";
	}
	public Order(int customerId, int cartId, Date deliveredDate, int orderId, String deliveryStatus,
			int transactionId) {
		super();
		this.customerId = customerId;
		this.cartId = cartId;
		this.deliveredDate = deliveredDate;
		this.orderId = orderId;
		this.deliveryStatus = deliveryStatus;
		this.transactionId = transactionId;
	}
	public Order() {}
}
