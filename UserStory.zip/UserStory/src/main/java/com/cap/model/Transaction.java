package com.cap.model;

public class Transaction {
private int transactionId;
private Order orderId;
private double amount;
private int transactionStatus;
private String modeOfPurchase;
public int getTransactionId() {
	return transactionId;
}
public void setTransactionId(int transactionId) {
	this.transactionId = transactionId;
}
public Order getOrderId() {
	return orderId;
}
public void setOrderId(Order orderId) {
	this.orderId = orderId;
}
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}
public int getTransactionStatus() {
	return transactionStatus;
}
public void setTransactionStatus(int transactionStatus) {
	this.transactionStatus = transactionStatus;
}
public String getModeOfPurchase() {
	return modeOfPurchase;
}
public void setModeOfPurchase(String modeOfPurchase) {
	this.modeOfPurchase = modeOfPurchase;
}
@Override
public String toString() {
	return "Transaction [transactionId=" + transactionId + ", orderId=" + orderId + ", amount=" + amount
			+ ", transactionStatus=" + transactionStatus + ", modeOfPurchase=" + modeOfPurchase + "]";
}
public Transaction(int transactionId, Order orderId, double amount, int transactionStatus, String modeOfPurchase) {
	super();
	this.transactionId = transactionId;
	this.orderId = orderId;
	this.amount = amount;
	this.transactionStatus = transactionStatus;
	this.modeOfPurchase = modeOfPurchase;
}
public Transaction() {
	
}

}
