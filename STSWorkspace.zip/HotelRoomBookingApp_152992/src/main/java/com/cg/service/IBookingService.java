package com.cg.service;

import java.util.List;

import com.cg.model.Hotel;

public interface IBookingService {

	public List<Hotel> getHotels();//1

	public Hotel getHotel(String name);

}
