package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IBookingDAO;

import com.cg.model.Hotel;

@Service("bservice")
public class BookingServiceImpl implements IBookingService {

@Autowired
private IBookingDAO bdao;

	//accessing the objects in DAO layer
	@Override
	public List<Hotel> getHotels() {
		
		return bdao.getHotels();
	}
	@Override
	public Hotel getHotel(String name) {
		
		return bdao.getHotel(name);
	}

	
	
		
	}


