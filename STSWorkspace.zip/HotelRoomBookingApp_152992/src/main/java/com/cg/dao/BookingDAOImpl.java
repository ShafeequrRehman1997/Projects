package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.model.Hotel;


@Repository("bdao")
@Transactional
public class BookingDAOImpl implements IBookingDAO {
	@PersistenceContext
	private EntityManager entityManager;
	
	
	//getting hotel details from database
	@Override
	@Transactional
	public List<Hotel> getHotels() {
		List<Hotel> hotels =entityManager.createQuery("from Hotel").getResultList();
		return hotels;
	}
	
	//finding a particular hotel from database
	@Override
	@Transactional
	public Hotel getHotel(String name) {
		Hotel hotels=entityManager.find(Hotel.class, name);
		return hotels;
	}

}
