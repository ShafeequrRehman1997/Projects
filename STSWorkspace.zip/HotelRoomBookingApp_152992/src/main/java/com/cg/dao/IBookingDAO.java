package com.cg.dao;

import java.util.List;

import com.cg.model.Hotel;

public interface IBookingDAO {

	public List<Hotel> getHotels();

	public Hotel getHotel(String name);

}
