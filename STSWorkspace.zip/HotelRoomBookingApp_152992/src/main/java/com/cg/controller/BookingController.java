package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.model.Hotel;

import com.cg.service.IBookingService;


@Controller
public class BookingController {
	@Autowired
	private IBookingService bservice;
	
	//Displaying the hotels
	@RequestMapping("/")
	public String showHotels(ModelMap map)
	{	
		List<Hotel> rooms=bservice.getHotels();
		map.put("p1", rooms);
		return "HotelDetails";
	}
	
	//Booking a hotel
	@RequestMapping("/showHotel/{name}")
	public String getHotel(ModelMap map,@PathVariable("name") String name)
	{	
	
	String hotel=name;
	map.put("hotel", hotel);
		return "BookingConfirmation";
	}
	
	
}