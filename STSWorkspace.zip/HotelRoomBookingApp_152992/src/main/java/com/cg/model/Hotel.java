package com.cg.model;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


//referring the table in the database
@Entity
@Table(name="HotelDetails")
public class Hotel {
	@Id//persistence id
	private int id;//hotel id
	private String name;//hotel name
	private String rating;//hotel rating
	private double rate;//hotel rate
	private int availableRooms;//no. of rooms available in that hotel
	
	//Getters ans Setters
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public double getRate() {
		return rate;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}
	public int getAvailableRooms() {
		return availableRooms;
	}
	public void setAvailableRooms(int availableRooms) {
		this.availableRooms = availableRooms;
	}
	
	//to string() method
	@Override
	public String toString() {
		return "Hotel [id=" + id + ", name=" + name + ", rating=" + rating + ", rate=" + rate + ", availableRooms="
				+ availableRooms + "]";
	}
	
	
	//constructors
	public Hotel(int id, String name, String rating, double rate, int availableRooms) {
		super();
		this.id = id;
		this.name = name;
		this.rating = rating;
		this.rate = rate;
		this.availableRooms = availableRooms;
	}
	public Hotel() {
		super();

	}
	
	
}
