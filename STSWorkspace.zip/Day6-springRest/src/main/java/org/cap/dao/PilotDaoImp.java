package org.cap.dao;



import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.concurrent.atomic.AtomicInteger;




import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;


@Repository("pilotDao")
//@Transactional
public class PilotDaoImp implements PilotDao{
	private static AtomicInteger pilotId=new AtomicInteger(1000);
	public static List<Pilot> pilots=dummyDBPilots();
	public static List<Pilot> dummyDBPilots(){
		List<Pilot> pilots=new ArrayList<>();
		pilots.add(new Pilot(pilotId.incrementAndGet(),"tyfhghf","utwfryu",new Date(1997-1900,03,02),new Date(2018-1900,02,03),true,20000.0));
		pilots.add(new Pilot(pilotId.incrementAndGet(),"tyfhsegfghf","uwwfryu",new Date(1997-1900,03,02),new Date(2018-1900,02,03),true,20000.0));
		pilots.add(new Pilot(pilotId.incrementAndGet(),"tyfhetwghf","rwarufryu",new Date(1997-1900,03,02),new Date(2018-1900,02,03),true,20000.0));
		pilots.add(new Pilot(pilotId.incrementAndGet(),"tytrawfhghf","ufweftwryu",new Date(1997-1900,03,02),new Date(2018-1900,02,03),true,20000.0));
		return pilots;
	}
	@Override
	public List<Pilot> getAll() {
		return pilots;
		
		
	}
	@Override
	public Pilot findPilot(Integer pilotId) {
		for (Pilot pilot : pilots) {
			if(pilotId==pilot.getPilotId())
			{
				return pilot;
			}
		
		}
		return null;
	}
	
	@Override
	public List<Pilot> deletePilot(Integer pilotId) {
		boolean flag=false;
		Iterator<Pilot> it=pilots.iterator() ;
while(it.hasNext())
{
	
	Pilot pilot=it.next();

	if(pilot.getPilotId()==pilotId)
	{
		it.remove();
		flag=true;
		break;
	}
		}
if(flag)
	return pilots;
else
	
	
return null;
	}
	@Override
	public List<Pilot> createPilot(Pilot pilot) {
		pilots.add(pilot);
		return pilots;
	}
	
	@Override
	public List<Pilot> updatePilot(Pilot pilot) {
		
		for (Pilot pilot1 : pilots) {
			if(pilot.getPilotId()==pilot1.getPilotId())
			{int i=pilots.indexOf(pilot1);
				pilots.remove(pilot1);
				pilots.add(i,pilot);
				return pilots;
			}
		}
		pilots.add(pilot);
		return pilots;
	}
	
	

}


	 
  
	
 
