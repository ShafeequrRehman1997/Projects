package org.cap.service;

import java.util.Date;
import java.util.List;

import org.cap.model.Account;
import org.cap.model.Transaction;

public interface AccountService {
	public void createAccount(Account account);
	public List<Account>getAllAccounts(int customerId);
	public List<Account> getAccountWithBalance(int custId);	
	public Account findAccount(long accnum);
	public void depositWith(Transaction transaction);
	public void FundTransfer(Transaction transaction);
	public List<Account> getOtherAccount(Integer customerId);
	public Account findAccount1(long accnum1);	
	public List<Transaction> getTransactions(Integer customerId);
	
	public List<Transaction> getDatedTransactions(Integer id,Date d1,Date d2);
		
}
