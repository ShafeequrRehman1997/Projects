package Page;

public class LoginPageBean {

}
