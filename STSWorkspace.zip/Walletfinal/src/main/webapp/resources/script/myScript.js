function showButton(){
	if(document.getElementById('credit').checked){
		document.getElementById('btnType').value="Deposit";
	}else{
		document.getElementById('btnType').value="Withdraw";
	}
}



function showYearDiv(){
	if(document.getElementById('rd').checked ||
			document.getElementById('fd').checked)
		document.getElementById('yearsDiv').style.display='block';
	else
		document.getElementById('yearsDiv').style.display='none';
}




window.onload= function(){
	document.getElementById('yearsDiv').style.display='none';
}


function showButton()
{
	if(document.getElementById('credit').checked){
		document.getElementById('btnType').value="Deposit";
	}else{
		document.getElementById('btnType').value="Withdraw";
	}

}


function val()
{   
	
	var flag=false;
	if(document.getElementById('savings').checked){
	
		var v=myform1.openingBalance.value;
		
		//document.write(v);
		if(v<1000)
		document.getElementById('accErr').innerHTML="Minimum amount should be 1000";
		else
			flag=true;
	}
	else if(document.getElementById('current').checked)
	{	var v=myform1.openingBalance.value;
		if(v<10000)
		document.getElementById('accErr').innerHTML="Minimum amount should be 10000";
		else
			flag=true;
	}
	else if(document.getElementById('rd').checked)
	{
		var v=myform1.openingBalance.value;
		if(v<100)
		document.getElementById('accErr').innerHTML="Minimum amount should be 100";
		else
			flag=true;

	}
	else if(document.getElementById('fd').checked)
	{
		var v=myform1.openingBalance.value;
		if(v<500)
		document.getElementById('accErr').innerHTML="Minimum amount should be 500";
		else
			flag=true;

	}
	else
		{
		document.getElementById('accErr').innerHTML="Please Choose account Type";
		}
	return flag;
}





function validateForm(){
	var uname=myform.userName.value;
	var upwd=myform.userPwd.value;
	
	var flag=false;
	if(uname==""||uname==null){
		document.getElementById('userErrMsg').innerHTML=" * Please enter userName.";
		
	}
	else if(upwd=="" || upwd==null)
		{
		flag=false;
		document.getElementById('userErrMsg').innerHTML="";
		document.getElementById('pwdErrMsg').innerHTML=" * Please enter password.";
		}
	else{
		flag=true;
		document.getElementById('userErrMsg').innerHTML="";
		document.getElementById('pwdErrMsg').innerHTML="";
	}
	
	return flag;
}

function validate2()
{
  var amount=myform2.amount.value;
  var flag=false;
  if(amount<=0)
	  {
	     document.getElementById("errAmount").innerHTML="Amount should be greater than 0";
	     document.getElementById('errTransaction').innerHTML="";
	  }
  else if(document.getElementById('credit').checked||document.getElementById('debit').checked)
	  {
	    flag=true;
	  }
  else
	  {document.getElementById("errAmount").innerHTML="";
	  document.getElementById('errTransaction').innerHTML="Please Select a transaction type";
	  }
   return flag;
  
  
  
  
 

}


