package com.cg.service;

import java.util.List;

import com.cg.model.ProductDetails;

public interface IProductService {

	public List<ProductDetails> getProducts();//1

	public ProductDetails findProduct(String id);

	public void updateProduct(ProductDetails product2);

}
