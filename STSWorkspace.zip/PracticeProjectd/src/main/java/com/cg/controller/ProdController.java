package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.model.ProductDetails;
import com.cg.service.IProductService;
@Controller
public class ProdController {
	
	@Autowired
	private IProductService pservice;
	
	private ProductDetails productrec;
	
	@RequestMapping("/")
	public String showProduct(ModelMap map)
	{	
		List<ProductDetails> products=pservice.getProducts();
		map.put("p1", products);
		return "Product";
	}
	
	@RequestMapping("/update/{id}")
	public String findProduct(ModelMap map,@PathVariable("id") String id)
	{	
		productrec=pservice.findProduct(id);
		map.put("products", productrec);
	
		List<String> category=new ArrayList<>();
		category.add("Electronics");
		category.add("Home");
		category.add("Daily use");	
		
		map.put("categories", category);
		return "updateProduct";
	}
	
		
	@PostMapping("/update/saveProduct")
	public String saveProduct(ModelMap map,@ModelAttribute("products") ProductDetails product2)
	{
		pservice.updateProduct(product2);
		return "redirect:/";
	}	
	
	
	
}