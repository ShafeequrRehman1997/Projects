package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.cap.model.Student;
import org.springframework.stereotype.Repository;

@Repository("studentDao")
public class StudentDaoImpl implements IStudentDao {

	@PersistenceContext
	private EntityManager em;
	
	@Transactional
	@Override
	public List<Student> getStudents() {
		List<Student> students = em.createQuery("from Student").getResultList();
		return students;
	}

	@Override
	public void update(Student student) {
		if(student.getStudId()!=0)
			em.merge(student);
		else
			em.persist(student);
		
	}

	@Override
	public Student findStudent(Integer studId) {
		Student student= em.find(Student.class, studId);
		return student;
	}

}
