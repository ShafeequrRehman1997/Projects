package org.cap.model;



import java.util.Date;

/*import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;*/
import javax.validation.constraints.Future;

import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

import com.fasterxml.jackson.annotation.JsonFormat;
//@Entity
public class Pilot {
/*	@Id
	@GeneratedValue*/
	private int pilotId;
	//@NotEmpty(message="please enter pilot first name")
	private String firstName;
	//@NotEmpty(message="please enter pilot last name")
	private String lastName;
	@Past(message="please enter past date")
	@JsonFormat(pattern="dd-MMM-yyyy")
	private Date dateOfbirth;
	@Future(message="please enter future date")
	@JsonFormat(pattern="dd-MMM-yyyy")
	private Date dateOfJoining;
	private Boolean isCertified;
	//@Range(min=1000,max=200000,message="please enter the salary between 1k to 2lks")
private double salary;
	public Pilot() {
		
	}
	
	public int getPilotId() {
		return pilotId;
	}
	public void setPilotId(int pilotId) {
		this.pilotId = pilotId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Date getDateOfbirth() {
		return dateOfbirth;
	}
	public void setDateOfbirth(Date dateOfbirth) {
		this.dateOfbirth = dateOfbirth;
	}
	public Date getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	public Boolean getIsCertified() {
		return isCertified;
	}
	public void setIsCertified(Boolean isCertified) {
		this.isCertified = isCertified;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Pilot [pilotId=" + pilotId + ", firstName=" + firstName + ", lastName=" + lastName + ", dateOfbirth="
				+ dateOfbirth + ", dateOfJoining=" + dateOfJoining + ", isCertified=" + isCertified + ", salary="
				+ salary + "]";
	}
	public Pilot(int pilotId, String firstName, String lastName, Date dateOfbirth, Date dateOfJoining,
			Boolean isCertified, double salary) {
		super();
		this.pilotId = pilotId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfbirth = dateOfbirth;
		this.dateOfJoining = dateOfJoining;
		this.isCertified = isCertified;
		this.salary = salary;
	}
	
	
}