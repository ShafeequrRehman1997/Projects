package org.cap.controller;

import java.util.List;

import javax.validation.Valid;

import org.cap.modal.Pilot;
import org.cap.service.PilotService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@org.springframework.stereotype.Controller
public class Controller {

	@Autowired
	private PilotService pilotService;
	private Pilot pilot;
	@RequestMapping("/hii")
	public ModelAndView sayhii(
			
		) {
		String message="Welcome! GoodMorning!";
		
		return new ModelAndView("hello","msg",message);
	}	
		@RequestMapping("/ValidateLogin")
		
		public String ValidateLogin(ModelMap map,
				@RequestParam("UserName")String UserName,
				@RequestParam("Password")String Password) {
		if(UserName.equals("shafeeq") && Password.equals("shafeeq123")){
			List<Pilot> pilots=pilotService.getall();
			map.put("pilots", pilots);
			map.put("pilot", new Pilot());
					return "PilotForm";
		}
		return "redirect:/";
			
		}
		@RequestMapping("/PilotForm")
		public String getPilotForm(ModelMap map) {
			List<Pilot> pilots= pilotService.getall();
			
			map.put("pilots",pilots);
			if(pilot!=null) {
				map.put("pilot",pilot);
			}
			else {
			map.put("pilot", new Pilot());
			}
			return "PilotForm";
		}
		@PostMapping("/SavePilot")
		public String showPilotDetails(@Valid @ModelAttribute("pilot") Pilot pilot, BindingResult result) {
			/*if(pilot1!=null) {*/
				if(!result.hasErrors()) {
					
				pilotService.update(pilot);
				System.out.println(pilot);
			
				pilot=null;
			/*return "showPilot";*/
		}
			return "redirect:PilotForm";
	}
		@GetMapping("/delete/{pilotId}")
		public String deletePilot(@PathVariable("pilotId") Integer pilotId) {
			pilotService.delete(pilotId);
			
			return "redirect:/PilotForm";
			
}
		@GetMapping("/update/{pilotId}")
		public String updatePilot(@PathVariable("pilotId") Integer pilotId,ModelMap map) {
			pilot=pilotService.findPilot(pilotId);
			System.out.println(pilot);
			return "redirect:/PilotForm";		
}}