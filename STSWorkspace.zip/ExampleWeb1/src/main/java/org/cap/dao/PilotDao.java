package org.cap.dao;

import java.util.List;

import org.cap.modal.Pilot;

public interface PilotDao {

	public void save(Pilot pilot);
public List<Pilot> getall();
public void delete(Integer pilotId);
public void update(Pilot pilot);
public Pilot findPilot(Integer pilotId);
}

