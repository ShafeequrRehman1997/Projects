package org.cap.modal;


import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
@Entity
public class Pilot implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@GeneratedValue
	@Id
    private int pilotId;
	@NotEmpty(message="*Please Enter FirstName")
	private String firstName;
	@NotEmpty(message="*Please Enter LastName")
	private String lastName;
	
	private Date dateOfBirth;
	private Date dateOfJoin;
	private Boolean isCertified;
	@Range(min=10000,max=150000,message="*Enter valid salary")
	private double salary;
	
	public Pilot() {
		
	}

	public Pilot(int pilotId, String firstName, String lastName, Date dateOfBirth, Date dateOfJoin, Boolean isCertified,
			double salary) {
		super();
		this.pilotId = pilotId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.dateOfJoin = dateOfJoin;
		this.isCertified = isCertified;
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Pilot [pilotId=" + pilotId + ", firstName=" + firstName + ", lastName=" + lastName + ", dateOfBirth="
				+ dateOfBirth + ", dateOfJoin=" + dateOfJoin + ", isCertified=" + isCertified + ", salary=" + salary
				+ "]";
	}

	public int getpilotId() {
		return pilotId;
	}

	public void setpilotId(int pilotId) {
		this.pilotId = pilotId;
	}

	public String getfirstName() {
		return firstName;
	}

	public void setfirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getlastName() {
		return lastName;
	}

	public void setlastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getdateOfBirth() {
		return dateOfBirth;
	}

	public void setdateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Date getdateOfJoin() {
		return dateOfJoin;
	}

	public void setdateOfJoin(Date dateOfJoin) {
		this.dateOfJoin = dateOfJoin;
	}

	public Boolean getIsCertified() {
		return isCertified;
	}

	public void setIsCertified(Boolean isCertified) {
		this.isCertified = isCertified;
	}

	public double getsalary() {
		return salary;
	}

	public void setsalary(double salary) {
		this.salary = salary;
	}
	
	
}
