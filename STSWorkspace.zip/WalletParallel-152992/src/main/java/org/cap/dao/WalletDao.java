package org.cap.dao;

import java.util.List;

import org.cap.model.Account;
import org.cap.model.CustomerLogin;


public interface WalletDao {	
	public boolean validateLogin(int customerId, String custPwd);

	public String getCustomerName(int customerId);

	public CustomerLogin findCustomer(int customerId);
	//public void saveAccount(Account account);
	//public List<Account> getAllAccounts(int customerId);
	//public Account find(int customerId);
}
