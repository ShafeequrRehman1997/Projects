package org.cap.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Transient;

@Entity
public class Account {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int accountId;
	
	@Column(unique=true)
	private long accountNo;
	private String accountType;
	private double openingBalance;
	private Date openingDate;
	private int years;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="customerId")
	private CustomerLogin customer;
	
	private String status;
	
	@Transient
	private double updateBalance;
	
	
	@OneToMany(targetEntity=CustTransaction.class,mappedBy="fromAccount")
	private List<CustTransaction> fromTransactions;
	
	@OneToMany(targetEntity=CustTransaction.class,mappedBy="toAccount")
	private List<CustTransaction> toTransactions;

	public Account() {
		
	}
	
	public Account(int accountId, long accountNo, String accountType, double openingBalance, Date openingDate, int years,
			CustomerLogin customer, String status, double updateBalance, List<CustTransaction> fromTransactions, List<CustTransaction> toTransactions) {
		super();
		this.accountId = accountId;
		this.accountNo = accountNo;
		this.accountType = accountType;
		this.openingBalance = openingBalance;
		this.openingDate = openingDate;
		this.years=years;
		this.customer = customer;
		this.status = status;
		this.updateBalance = updateBalance;
		this.fromTransactions = fromTransactions;
		this.toTransactions = toTransactions;
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public double getOpeningBalance() {
		return openingBalance;
	}

	public void setOpeningBalance(double openingBalance) {
		this.openingBalance = openingBalance;
	}

	public Date getOpeningDate() {
		return openingDate;
	}

	public void setOpeningDate(Date openingDate) {
		this.openingDate = openingDate;
	}
	
	public int getYears() {
		return years;
	}

	public void setYears(int years) {
		this.years = years;
	}


	public CustomerLogin getCustomer() {
		return customer;
	}

	public void setCustomer(CustomerLogin customer) {
		this.customer = customer;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<CustTransaction> getFromTransactions() {
		return fromTransactions;
	}

	public void setFromTransactions(List<CustTransaction> fromTransactions) {
		this.fromTransactions = fromTransactions;
	}

	public List<CustTransaction> getToTransactions() {
		return toTransactions;
	}

	public void setToTransactions(List<CustTransaction> toTransactions) {
		this.toTransactions = toTransactions;
	}
	
	public double getUpdateBalance() {
		return updateBalance;
	}

	public void setUpdateBalance(double updateBalance) {
		this.updateBalance = updateBalance;
	}

	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", accountNo=" + accountNo + ", accountType=" + accountType
				+ ", openingBalance=" + openingBalance + ", openingDate=" + openingDate + ", years=" +years+ ", customer=" + customer
				+ ", status=" + status + ", fromTransactions=" + fromTransactions + ", toTransactions=" + toTransactions
				+ "]";
	}
	
	
	
}
