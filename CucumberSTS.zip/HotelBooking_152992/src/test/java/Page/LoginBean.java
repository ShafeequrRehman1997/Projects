package Page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginBean {
	WebDriver driver;
	@FindBy(name="userName")
	private WebElement userName;
	@FindBy(name="userPwd")
	private WebElement userPwd;

	@FindBy(name="login")
	private WebElement login;
	
	public LoginBean(WebDriver driver) {
		 this.driver=driver;
		 PageFactory.initElements(driver, this);
	}
	
	public void setUserName(String uname)
	{
		userName.sendKeys(uname);
	}

	public void setUserPwd(String pwd)
	{
		userPwd.sendKeys(pwd);
	}
	public void setSubmit()
	{
		login.submit();
	}
	public void loginTo_NextPagee(String userName,String userPwd) {
		 this.setUserName(userName);
		 this.setUserPwd(userPwd);
		this.setSubmit();
	}
}
