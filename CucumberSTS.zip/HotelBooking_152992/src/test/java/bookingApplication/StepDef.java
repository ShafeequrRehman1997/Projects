package bookingApplication;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import Page.DetailsBean;
import Page.LoginBean;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	private WebDriver driver;
	private WebElement element;
	private LoginBean loginBean;
	private DetailsBean detailsBean;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\sts-bundle\\sts-3.9.4.RELEASE\\chromedriver.exe");
		 driver=new ChromeDriver();
		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
		 loginBean=new  LoginBean(driver);
		  detailsBean=new DetailsBean(driver);
	}
	
	
	@Given("^login page$")
	public void login_page() throws Throwable {
		driver.get("http://localhost:8082//HotelBooking_152992/Login?userName=capgemini&userPwd=capg1234&submit=Login");
	}

	@When("^valid username and password$")
	public void valid_username_and_password() throws Throwable {
		loginBean.loginTo_NextPagee("capgemini","capg1234");
	}

	@Then("^validate login and navigate to Booking page$")
	public void validate_login_and_navigate_to_Booking_page() throws Throwable {
		driver.switchTo().alert().accept();
	}

	@Given("^booking page$")
	public void booking_page() throws Throwable {
		driver.get("http://localhost:8082//HotelBooking_152992/Confirm Booking?firstName=Shafeeq&lastName=mohd&address=dfs&city=dsgegf&state=trhd&email=abc@capgemini.com&mobilenum=3214569877&noOfRoomsBooked=8&"
				+ "noOfGuestsStaying=1&cardHolderName=yyjf&cardNo=1234123412341234&cvvNo=123&exMonth=03&exYear=2028&submit=Confirm Booking");

	}

	@When("^valid booking details$")
	public void valid_booking_details() throws Throwable {
		detailsBean.loginTo_NextPage1("Shafeeq", "mohd", "dfs", "dsgegf","trhd",	//
				"kug","3214569877","8","1",
				"yyjf","1234123412341234","123","03","2028");
	}

	@Then("^validate booking details and navigate to successfull page$")
	public void validate_booking_details_and_navigate_to_successfull_page() throws Throwable {
		driver.switchTo().alert().accept();
	}
	
	@After
	public void tearDown() {
		driver.close();
	}
}
