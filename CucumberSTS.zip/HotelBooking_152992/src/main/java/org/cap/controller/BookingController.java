package org.cap.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class BookingController {

	
	@RequestMapping("/")
	public String loginForm() {
		
		return "login";
		
	}
	@RequestMapping("/next")
	public String booking() {
		return "hotelbooking";
	}
@RequestMapping("/det")
public String successfull() {
	return "success";
}
}
