function validateForm(){
	//var firstname=myform.firstName.value;
	var firstName=document.forms["myform"]["firstName"].value;
	var lastName=document.forms["myform"]["lastName"].value;
	var address=document.getElementById("address").value;
	var city=document.getElementById("city");
	var state=document.getElementById("state");
	var gender=document.getElementById("gender");
	var course=document.getElementById("course");
	var phone=document.forms["myform"]["phone"].value;
	var phoneno = /^\d{10}$/;

	var flag=false;
	if(firstName==""||firstName==null){
		flag=false;
		window.alert("Please enter FirstName")
		//document.getElementById('userErrMsg').innerHTML=" * Please enter FirstName";
		
		
	}
	else if(lastName==""||lastName==null){
		flag=false;
		document.getElementById('lErrMsg').innerHTML=" * Please enter lastName";
		alert("Plzz enter last name");
		
	}
	else if(address==""||address==null){
		flag=false;
		document.getElementById('aErrMsg').innerHTML=" * Please enter address";
		
	}
	else if(city==""||city==null){
		flag=false;
		document.getElementById('cErrMsg').innerHTML=" * Please enter city";
		
	}
	else if(state==""||state==null){
		flag=false;
		document.getElementById('sErrMsg').innerHTML=" * Please enter state";
		
	}
	else if(gender==""||gender==null){
		flag=false;
		document.getElementById('gErrMsg').innerHTML=" * Please enter gender";
		
	}
	else if(course==""||state==null){
		flag=false;
		document.getElementById('coErrMsg').innerHTML=" * Please enter course";
		
	}
	else if(phone==""||phone==null){
		flag=false;
		document.getElementById('pErrMsg').innerHTML=" * Please enter phone";
		
		      
	}
	 
	 else if(!(phone.match(phoneno)))  {
		  flag =false;
		  document.getElementById('pErrMsg').innerHTML=" * Please enter valid phone";
	  }
	
	else {
		flag=true;
		alert("successfully entered personal details now  enter your bank details! ");
	 }
	
	return flag;
}

function validateForm1(){
	
	var cardHolderName=document.forms["my1form"]["cardHolderName"].value;
	var cardNumber=document.forms["my1form"]["cardNumber"].value;
	var cvv=document.forms["my1form"]["cvv"].value;
	document.getElementById("date").required = true;
	var letters = /^[A-Z ]+$/;
	var cvv1 = /^\d{3}$/;
	var number = /^\d{16}$/;
	var flag=false;
	
	if(cardHolderName==""||cardHolderName==null){
		
		flag=false;
		window.alert("Please enter Card Holder Name");
		//document.getElementById('userErrMsg').innerHTML=" * Please enter FirstName";
		
	}
	 else if(!(cardHolderName.match(letters)))  {
		  flag =false;
		  window.alert("Please enter valid Card Holder Name");
		  //document.getElementById('pErrMsg').innerHTML=" * Please enter valid phone";
	  }
	else if(cardNumber==""||cardNumber==null){
		flag=false;
		//document.getElementById('lErrMsg').innerHTML=" * Please enter card number";
		window.alert("Please enter card number");
		
		
	}
	 else if(!(cardNumber.match(number)))  {
		  flag =false;
		  window.alert("Please enter valid Card Number");
		  //document.getElementById('pErrMsg').innerHTML=" * Please enter valid phone";
	  }
	else if(cvv==""||cvv==null){
		flag=false;
		//document.getElementById('aErrMsg').innerHTML=" * Please enter cvv";
		window.alert("Please enter card cvv");
	}
	else if(!(cvv.match(cvv1)))  {
		  flag =false;
		  window.alert("Please enter valid cvv");
		  //document.getElementById('pErrMsg').innerHTML=" * Please enter valid phone";
	  }
	/*else if(date==""||date==null){
		flag=false;
		//document.getElementById('cErrMsg').innerHTML=" * Please enter expiry date";
		window.alert("Please enter card cvv");
	}*/
	else {
		flag=true;
		alert("sucessfully u have completed payment")
	} 
		
	return flag;
	 
}