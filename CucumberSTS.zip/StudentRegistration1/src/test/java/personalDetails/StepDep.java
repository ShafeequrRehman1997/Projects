package personalDetails;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDep {
	
	private WebDriver driver;
	private WebElement element;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\sts-bundle\\sts-3.9.4.RELEASE\\chromedriver.exe");
		driver=new ChromeDriver();
	}
	
	@Given("^Personal details$")
	public void personal_details() throws Throwable {
		driver.get("http://localhost:8081/StudentRegistration/");
	}

	@When("^valid personal details$")
	public void valid_personal_details() throws Throwable {
	    
	}

	@Then("^navigate to payment details page$")
	public void navigate_to_payment_details_page() throws Throwable {
	   
	}
}
