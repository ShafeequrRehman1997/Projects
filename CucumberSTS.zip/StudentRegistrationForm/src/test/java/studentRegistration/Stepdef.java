package studentRegistration;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import Page.PaymentPageBean;
import Page.StudentPageBean;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class Stepdef {
	private WebDriver driver;
	private StudentPageBean studentPageBean;	//object for bean classes
	private PaymentPageBean  paymentPageBean;	//
	private WebElement element;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\sts-bundle\\sts-3.9.4.RELEASE\\chromedriver.exe");
		 driver=new ChromeDriver();
		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 studentPageBean=new  StudentPageBean(driver);
		 paymentPageBean=new PaymentPageBean(driver);
	}
	@Given("^registration page$")
	public void registration_page() throws Throwable {
	  driver.get("http://localhost:8081/StudentRegForm/");
	}

	@When("^valid student details$")
	public void valid_student_details() throws Throwable {
	studentPageBean.loginTo_NextPage("Shafeeq","Mohd","kingkoti","Hyderabad","Telangana","Male","B.E.","9700942665");
		
	
	   
	}

	@Then("^register student and navigate to payment$")
	public void register_student_and_navigate_to_payment() throws Throwable {
		/* String url= driver.getCurrentUrl();
		 assertTrue(url.equals("http://localhost:8082/StudentRegForm/next?firstName=Likitha&lastName=Pinky&address=gfdd&city=Hyderabad&state=telangana&gender=female&course=be&mobilenum=9789596045"));*/
		driver.switchTo().alert().accept();
	}

	@Given("^payment page$")
	public void payment_page() throws Throwable {
	 driver.get("http://localhost:8081/StudentRegForm/next?firstName=Shafeeq&lastName=Mohd&address=kingkoti&city=Hyd&state=Telangana&gender=Male&course=B.E.&mobilenum=9700942665");
	   
	}

	@When("^valid payment details$")
	public void valid_payment_details() throws Throwable {
	    paymentPageBean.Payment_succesfull("SHAFEEQUR", "1111111111111111", "123", "02/20");
	}

	@Then("^payment successfull$")
	public void payment_successfull() throws Throwable {
	   driver.switchTo().alert().accept();
	}


}
