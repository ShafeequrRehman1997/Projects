package org.cap.demo;

import org.junit.internal.runners.statements.ExpectException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Selenium2Example {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "D:\\sts-bundle\\sts-3.9.4.RELEASE\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://localhost:8081/WalletApp/");
		
		/*WebElement element=driver.findElement(By.name("q"));
		element.sendKeys("cheese!");
		element.submit();*/
		
		WebElement element=driver.findElement(By.name("customerId"));
		WebElement element2=driver.findElement(By.name("customerPwd"));
		element.sendKeys("21");
		element2.sendKeys("shafeeq123");
		
		element.submit();
		
		
		(new WebDriverWait(driver, 10)).until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				return d.getTitle().toLowerCase().startsWith("cheese!");
			}
		});
		
		
		
		
		
		
		System.out.println("page title: "+driver.getTitle());
		driver.close();
}
}