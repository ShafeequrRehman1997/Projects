
public class Person {

	private int id;
	private String name;
	public Person(int id, String name) {
		this.id = id;
		this.name = name;
	}
	public void display() {
		System.out.println(id);
		System.out.println("name="+name);
	}
	public Person() {
		System.out.println("ehjd");
	}
}
