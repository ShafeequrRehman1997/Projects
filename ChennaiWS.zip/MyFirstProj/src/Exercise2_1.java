enum GENDER{M,F};
public class Exercise2_1 {

	public static void main(String[] args) {
		
		/*System.out.println("person details");
		System.out.println("_____________");
		Employee e= new Employee();
		e.setFirstName("jghftyf");
		System.out.println("fname="+e.getFirstName());
		e.setLastName("yf");
		System.out.println("lname="+e.getLastName());
		e.setAge(23);
		System.out.println("age="+e.getAge());
		e.setGender(GENDER.F);
		System.out.println("gender="+e.getGender());
		e.setWeight(45.88f);
		System.out.println("weight="+e.getWeight());
		e.setPhone(0123456789d);
		System.out.println("phone="+e.getPhone());
		*/
		
	}

}