public class MainApp {
	
	public static void main(String[] args) {
	
	


}
}























/*	//UtilClass u=new UtilClass();
//System.out.println(u.areEqual("A",11)); //this is senseless since it is comparing different data types though compiled............so we came up with generics

UtilClass<Integer> u=new UtilClass<Integer>();//same for <string> also
System.out.println(u.areEqual(10,10));
// and for this case
//System.out.println(u.areEqual("A",11));
UtilClass<Employee> u1=new UtilClass<Employee>();
Employee e1=new Employee("RAMU", 101, 123.45F, "F");
Employee e2=new Employee("RAMU", 101, 123.45F, "F");

System.out.println(u1.areEqual(e1, e2));*/