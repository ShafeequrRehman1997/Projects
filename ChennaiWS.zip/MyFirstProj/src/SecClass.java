
public class SecClass {

	void display(int a) {
		int j=20;
		j=j+a;
	
		System.out.println("j"+j);
		
	}

}
