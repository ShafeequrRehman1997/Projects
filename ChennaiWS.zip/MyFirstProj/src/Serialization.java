import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Serialization {

	public static void main(String[] args) throws IOException {
		/*Employee emp=new Employee();
		emp.setId(1001);
		emp.setSal(23333.12);
		FileOutputStream fos=new FileOutputStream("d:/msr_25_6_1");
		ObjectOutputStream out=new ObjectOutputStream(fos);
		out.writeObject(emp);
		out.close();
		fos.close();
		System.out.println("employee object written!");
	*/
		
	}
}