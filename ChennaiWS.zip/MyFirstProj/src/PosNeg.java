
public class PosNeg {

	
		/*int a=Integer.parseInt(args[0]);
		System.out.println(a);
		
		
		if(a>=0) {
			System.out.println("positive");
		}
		else
		{ System.out.println("negative");
		}
*/
		static void procA() {
			try {
			System.out.println("inside procA");
			throw new RuntimeException("demo");
			} finally { System.out.println("procA'sfinally"); }
			}
			static void procB() { // Return from within a try block.
			try {
			System.out.println("inside procB");
			return;
			} finally { System.out.println("procB'sfinally"); }
			}
			static void procC() { // Execute a try block normally.
			try {
			System.out.println("inside procC");
			} finally { System.out.println("procC'sfinally"); }
			}
			public static void main(String[] args) {
			try {
			procA();
			} catch (Exception e) { System.out.println("Exception caught"); }
			procB(); procC();
			} }