public class Employee implements Comparable<Employee> {
private String name;
private int id;
private double sal;
private String gender;


public Employee() {
	
	this.name = name;
	this.id = id;
	this.sal = sal;
	this.gender = gender;
}

public Employee(String name, int id, double sal, String gender) {
	super();
	name = name;
	this.id = id;
	this.sal = sal;
	this.gender = gender;
}

public String getName() {
	return name;
}
public void setName(String name) {
	name = name;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public double getSal() {
	return sal;
}
public void setSal(double sal) {
	this.sal = sal;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
@Override
public String toString() {
	return "Employee [Name=" + name + ", id=" + id + ", sal=" + sal + ", gender=" + gender + "]";
}

@Override
public int compareTo(Employee e) {
	if(id>e.id)
	{ return 1; }
	else if(id<e.id) { return -1; }
	else
	return 0;
}

@Override
public boolean equals(Object obj) {
	// TODO Auto-generated method stub
	return super.equals(obj);
}

}





/*String firstName="ram";
String lastName="rohan";
String gender="F";
int age=45;
float weight=45.88f;

System.out.println("Person details");
System.out.println("______________");
System.out.println("first name:"+firstName);
System.out.println("last name:"+lastName);
System.out.println("gender:"+gender);
System.out.println("age:"+age);
System.out.println("weight:"+weight);
*/





/*public int getId() {
	return id;
}
public void setId(int i) {
		id=i;
	}
public int getAge() {
	return age;
}
public void setAge(int a) {
	if(a>=18 && a<=60) {
	age=a;
	}
	}
	 String name;
		public void display() {
		System.out.println(name);
	}
	public void display1()
	{
		System.out.println();

	static int empCount;
public Employee() {
		empCount++;
	}
}	*/
