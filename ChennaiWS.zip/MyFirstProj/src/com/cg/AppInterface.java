//review questions
//q1.op4
//q2.bipredicate
//q3.true
package com.cg;
//Lambda Interface must be used only with functional interface
/*interface maxInterface{
	public int maximum(int a,int b);
}*/
interface Greetable{
	String greet(char[] c);
}

/*@FunctionalInterface
interface MyInterface{
	public void display();
	int i=10;		//final//static
	default void print() {
		System.out.println("hello");
	}
	static void myMethod() {
		System.out.println("hello frm myMethod");
	}
}
*/

//class AppInterface implements MyInterface {

	class AppInterface{
		

/*	@Override
	public void display() {
		System.out.println("hello frm display");
		
	}*/
public static void main(String[] args) {
		
/*	 maxInterface m=(x,y) -> (x>y?x:y);	//lambda expression
	int res=m.maximum(10,20);
	System.out.println(res);*/
	char[] arr= {'w','e','l','c','o','m','e'};
	Greetable g= (x->new String(x));
	//Greetable g=String::new;
String str=g.greet(arr);
System.out.println(str);
	}
}
