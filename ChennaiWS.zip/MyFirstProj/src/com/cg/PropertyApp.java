//review ques lesson18
//q1.inputsream
//q2.false
//q3.opt1
package com.cg;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Properties;



public class PropertyApp {

	public static void main(String[] args) throws IOException {
	//Mydata.properties was created by us	
FileInputStream fis=new FileInputStream("MyData.properties");
Properties p=new Properties();
p.load(fis);//////////////////////////////////////////////////////////////
System.out.println(p.getProperty("name"));
System.out.println(p.getProperty("company"));
System.out.println(p.getProperty("city","Chennai"));
System.out.println(p.getProperty("pin"));
System.out.println(p.getProperty("fruits"));
//p.remove("name");
//System.out.println(p.getProperty("name"));	//returns null
  
 
/*Enumeration e=p.elements();
while(e.hasMoreElements())
{
	System.out.println(e.nextElement());//returns Capgemini
										//500001
										//shafeeq
										//Chennai
}*/
/*fis.close();
	FileOutputStream out=new FileOutputStream("data.properties");//data.properties is created by code
	p.store(out, "this is a duplicate properties");/////////////////
	out.close();*/
	
/*FileOutputStream fos=new FileOutputStream("a.properties");//a.propperties too was created by code
PrintStream ps=new PrintStream(fos);
p.list(ps);
ps.close();
fos.close();*/


/*FileWriter out =new FileWriter("b.properties");//b.propperties too was created by code
PrintWriter pw=new PrintWriter(out);
p.list(pw);
out.close();
pw.close();*/



/*Properties p1=new Properties();
p1.setProperty("db.user", "shafeeq");
p1.setProperty("db.password", "myPassword");
p1.setProperty("db.url", "jdbc:oracle:thin:@localhost:1521:ORCL");
p1.setProperty("db.driver", "oracle.jdbc.driver.OracleDriver");
FileOutputStream out=new FileOutputStream("db.properties");//db.propperties too was created by code
p1.store(out, "database connectivity properties");
out.close();
System.out.println();
System.out.println("done!!!!");*/
	}
}
