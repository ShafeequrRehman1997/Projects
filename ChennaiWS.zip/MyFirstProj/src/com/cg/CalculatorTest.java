package com.cg;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;

class CalculatorTest {
Calculator c;
@Before
public void init() {
	c=new Calculator();
	System.out.println("init executed");
}
@Test
void testAdd() {
	c=new Calculator();
	assertEquals(24, c.add(14, 10));
	//fail("Not yet implemented");
}

@Test
void testSub() {
	c=new Calculator();
	assertEquals(4, c.sub(14, 10));
	//fail("Not yet implemented");
}
/*@Test
void testDiv() {
	c=new Calculator();
	assertEquals(3, c.div(9,0));
}*/

@After
public void tearDown() {
	c=null;
	System.out.println("teardown executed");
}
@BeforeClass
public static void superInit() {
	
	System.out.println("superinit executed");
}
@AfterClass
public static void superShutDown() {

	System.out.println(" superShutDow executed");
}	

}
