//q1.op1
//q2.stream
//q3.true
package com.cg;
import java.util.*;
import java.util.stream.*;
//import java.util.stream.Stream;
//import java.util.Optional;
public class StreamClass {

	public static void main(String[] args) {
	Stream<Integer> numbers= Stream.of(10,34,12,9);
	Optional<Integer> num= numbers.min((x,y)->x>y?1:x<y?-1:0);
	System.out.println(num.get());
	}

}