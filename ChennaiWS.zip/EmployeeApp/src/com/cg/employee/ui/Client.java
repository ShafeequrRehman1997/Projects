package com.cg.employee.ui;
import java.util.Collection;
import java.util.List;
import java.util.Scanner;
import com.cg.employee.bean.Employee;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.service.EmployeeService;
import com.cg.employee.service.EmployeeServiceImpl;

public class Client {
Scanner sc=new Scanner(System.in);	
	public static void main(String[] args) {
		String option=null;
	
		Client c=new Client();
		while(true) {
			System.out.println("=============Employee Management System=============");
			System.out.println("1. Add an Employee");
			System.out.println("2. Display all Employees");
			System.out.println("3. Display an Employee");
			System.out.println("4. Delete an Employee");
			System.out.println("5. update an Employee");
			System.out.println("6. Exit");
			System.out.println("7. view employee based on salary");
			
			System.out.println("choose an option");
			option=c.sc.nextLine();
			switch (option) {
			case "1":
						c.addEmployee();
				break;
				
			case "2":
						c.getAllEmployees();
				break;

			case "3":
						c.getEmployeeById();
				break;
				
			case "4":
						c.deleteEmployee();
				break;
				
			case "5":	c.updateEmployee();
				
				break;
				
			case "6":
						System.exit(0);
				break;
				
			case "7":
						c.getEmployeeBySalary();
				break;
				
			default:
						System.err.println("inavlid option,....choose from 1 to 6");
						System.out.println();
				break;
			}
		}

	}
	public void updateEmployee() {
		System.out.println("enter employee id");
		String id=sc.nextLine();
		try {
		int empid=Integer.parseInt(id);
		boolean result=employeeService.updateEmployee(empid);
		{
			System.out.println("employee with id "+empid+" has been successfully updated");
		}
		}
		catch(EmployeeException e) {
			System.err.println("An error occured "+e.getMessage());
		}
	
		
	
		
	}
	private EmployeeService employeeService=new EmployeeServiceImpl();
	
	public void getAllEmployees() {
		try{
			Collection<Employee> employees=employeeService.getAllEmployees();
			employees.stream().sorted((x,y) -> x.getSalary()>y.getSalary()?-1:x.getSalary()<y.getSalary()?1:0).forEach(System.out::println);
			// or    employees.forEach(System.out::println);
			}
		catch(EmployeeException e) {
			System.err.println("An error occured "+e.getMessage());
		}
		
	}


public void getEmployeeById() {
	System.out.println("enter employee id");
	String id=sc.nextLine();
	

try {
	int empId=Integer.parseInt(id);
	Employee emp=employeeService.getEmployeeById(empId);
	System.out.println(emp);
}
catch(EmployeeException e) {
	System.err.println("an error occured "+e.getMessage());
}
}

public void deleteEmployee() {
	System.out.println("enter employee id");
	String id=sc.nextLine();
	
	try {
	int empId=Integer.parseInt(id);
	boolean result=employeeService.deleteEmployee(empId);
	if(result) {
		System.out.println("employee with id "+id+" successfully deleted");
	}
}
	catch(EmployeeException ex) {
		System.err.println("an error occured "+ex.getMessage());
	}
}




public void addEmployee() {
	Employee emp=new Employee();
	System.out.println("Enter employee id");
	String id=sc.nextLine();
	int empId=Integer.parseInt(id);
	emp.setId(empId);
	//emp.setId(Integer.parseInt(sc.nextLine()));
	System.out.println("Enter employee name");
	emp.setName(sc.nextLine());
	System.out.println("enter mobile");
	emp.setMobile(sc.nextLine());
	System.out.println("enter email");
	emp.setEmail(sc.nextLine());
	System.out.println("enter salary");
	emp.setSalary(Double.parseDouble(sc.nextLine()));
	
	try {
		boolean result=employeeService.validateEmployee(emp);
		if(result) {
			int ret= employeeService.addEmployee(emp);
			System.out.println("Employee with id "+ret+" added successfully");
		}
		//System.out.println("validated!");
	} catch (EmployeeException ex) {
			System.out.println();
			System.err.println("an error occured "+ex.getMessage());
			System.out.println();
	}
	
}
public void getEmployeeBySalary() {
			System.out.println("Enter salary");
			System.out.println("\\those who are earning greater than the above given salary is shown below ");
			System.out.println("\\between so and so salary to so and so salary use && operator in method ");
			try {
			double salary=Double.parseDouble(sc.nextLine());
			Collection<Employee> employees=employeeService.getEmployeeBySalary(salary);
			employees.forEach(System.out::println);
			}
			catch(EmployeeException e) {
				System.out.println();
				System.err.println("an error occured "+e.getMessage());
				System.out.println();
			}
			catch(Exception e) {
				System.out.println();
				System.err.println("An error occured "+e.getMessage());
				System.out.println();
			}
}
}

