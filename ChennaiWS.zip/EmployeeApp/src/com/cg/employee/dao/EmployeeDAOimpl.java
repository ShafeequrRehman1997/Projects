package com.cg.employee.dao;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
import com.cg.employee.bean.Employee;
import com.cg.employee.db.EmployeeDB;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.service.EmployeeService;
import com.cg.employee.service.EmployeeServiceImpl;
/**
 * *
 *  author: shafemoh
 *
 * 
 *
 */
public class EmployeeDAOimpl implements EmployeeDAO {
	static HashMap<Integer, Employee> empMap=EmployeeDB.getEmployeeMap();
/**
 * Method name: getAllEmployees
 * parameters: nil
 * return type: collection of employees
 * purpose: retrieves all the data from the underlying data store
 * author: shafemoh
 * date of creation: 20th june 2018
 * last modified date: 20th june 2018
 */
	
		@Override
	public Collection<Employee> getAllEmployees() throws EmployeeException {
		try{
			Collection<Employee> employees=(Collection<Employee>)empMap.values();
			return employees;
			//Collection<Employee> employees= employeeService.getAllEmployees();
			
			
			 
			
		}
		catch (Exception ex) {
				throw new EmployeeException(ex.getMessage());
		}

	}

	@Override
	public Employee getEmployeeById(int id) throws EmployeeException {
		try {
			Employee employee=empMap.get(id);
			
			if(employee==null) {
				throw new EmployeeException("Employee with the Id "+id+" not available in database");
			}
			return employee;
		}
		catch (Exception ex) {
			throw new EmployeeException(ex.getMessage());
		}
	
	}

	@Override
	public boolean deleteEmployee(int id) throws EmployeeException {
		try {
			Employee emp=empMap.remove(id);
			if(emp==null) {
				throw new EmployeeException("Employee with id "+id+" has been removed");
			}
		}
		catch(Exception ex) {
			throw new EmployeeException(ex.getMessage());
		}
		return true;
	}
	
	public int addEmployee(Employee emp) throws EmployeeException {
		try {
		Employee e=empMap.get(emp.getId());
		if(e!=null) {
			throw new EmployeeException("Employee with id "+emp.getId()+" already exists");
		}
		else {
			empMap.put(emp.getId(), emp);
		}
	}
	catch(Exception ex) {
		throw new EmployeeException(ex.getMessage());
	}
	return emp.getId();
}

	@Override
	public Collection<Employee> getEmployeeBySalary(double salary) throws EmployeeException {
		List<Employee> employees= empMap.values().stream().filter(x -> x.getSalary()>=salary).collect(Collectors.toList());
		return employees;
	}

	@Override
	public boolean updateEmployee(int id) throws EmployeeException {
		EmployeeService empser=new EmployeeServiceImpl();
		Scanner sc=new Scanner(System.in);
		boolean res1,res2,res3;
		try {
			Employee emp=empMap.get(id);
			if(emp==null) {
				throw new EmployeeException("employee with id "+id+"not available");
			}
			else {
				String name=emp.getName();
				String mobile=emp.getMobile();
				String email=emp.getEmail();
				double salary=emp.getSalary();
				System.out.println("Name:"+name);
				System.out.println("Mobile:"+mobile);
				System.out.println("email:"+email);
				System.out.println("salary:"+salary);
				System.out.println("enter name");
				name=sc.nextLine();
				System.out.println("enter mobile");
				mobile=sc.nextLine();
				System.out.println("enter email");
				email=sc.nextLine();
				System.out.println("enter salary");
				salary=sc.nextDouble();
				res1=empser.validateName(name);
				res2=empser.validateMobile(mobile);
				res3=empser.validateEmail(email);
				
				if(res1 && res2 &  res3) {
				emp.setName(name);
				emp.setMobile(mobile);
				emp.setEmail(email);
				emp.setSalary(salary);
				System.out.println("Updated!!");
				}
		
			}
		}
		catch(EmployeeException e) {
			System.out.println(e.getMessage());
		}
		return true;
	}
}
