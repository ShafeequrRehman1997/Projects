package com.cg.employee.service;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

import com.cg.employee.bean.Employee;
import com.cg.employee.exception.EmployeeException;

public interface EmployeeService {
	Collection<Employee> getAllEmployees() throws EmployeeException;
	Employee getEmployeeById(int id) throws EmployeeException;
	boolean deleteEmployee(int id) throws EmployeeException;
	boolean validateEmployee(Employee emp) throws EmployeeException;
	int addEmployee(Employee emp) throws EmployeeException;
	Collection<Employee> getEmployeeBySalary(double salary) throws EmployeeException;
	boolean updateEmployee(int empid) throws EmployeeException;
	boolean validateName(String name) throws EmployeeException;
	boolean validateMobile(String mobile) throws EmployeeException;
	boolean validateEmail(String email) throws EmployeeException;
	

}
