package com.cg.employee.db;
import java.util.HashMap;
import com.cg.employee.bean.Employee;

public class EmployeeDB {
	
	private static HashMap<Integer, Employee> employeeMap =new HashMap<Integer, Employee>();
	public static void setEmployeeMap(HashMap<Integer, Employee> employeeMap) {
		EmployeeDB.employeeMap=employeeMap;
	}
	static {
		employeeMap.put(1001, new Employee(1001,"sam","9999999999","hsg@gma.com",89423));
		employeeMap.put(1002, new Employee(1002,"hsd","9999999923","hsdfg@gma.com",84550));
		employeeMap.put(1003, new Employee(1003,"aksj","9999999459","hefwsg@gma.com",89870));
		employeeMap.put(1004, new Employee(1004,"dkjc","9999999889","hsw4tr2g@gma.com",45000));
		employeeMap.put(1005, new Employee(1005,"njf","9999999987","hs23rg@gma.com",99000));
	}

	public static HashMap<Integer, Employee> getEmployeeMap() {
		return employeeMap;
	}
	
}