package com.cg.employee.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Collection;
import java.util.Collections;

import org.junit.jupiter.api.Test;

import com.cg.employee.bean.Employee;
import com.cg.employee.dao.EmployeeDAO;
import com.cg.employee.dao.EmployeeDAOimpl;
import com.cg.employee.exception.EmployeeException;

class EmployeeDAOimplTEST {
	EmployeeDAO dao=new EmployeeDAOimpl();
		
	
	
	@Test
	public void testGetEmployeeById() {
		try {
			Employee emp=dao.getEmployeeById(1002);
			assertNotNull(emp);
			Employee emp1=dao.getEmployeeById(2000);
			assertNotNull(emp1);
		}
		catch(EmployeeException e) {
			e.printStackTrace();
		}
	}
	@Test
	public void testGetAllEmployees() {
		try {
			Collection<Employee> employees=dao.getAllEmployees();
			assertEquals(5, employees.size());
		}
		catch(EmployeeException e) {
			e.printStackTrace();
		}
	}
	public void testDeleteEmployee() {
		try {
			boolean b=dao.deleteEmployee(1001);
			assertTrue(b);
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
	}
@Test//(expected=EmployeeException.class)
public void testAddEmployee() throws EmployeeException {
	Employee emp=new Employee();
	emp.setId(1005);
	emp.setName("Chinnu");
	emp.setMobile("9999999999");
	emp.setEmail("Sabc@hak.com");
	emp.setSalary(50000);
	
	//try {
		dao.addEmployee(emp);
	//}
	//catch(EmployeeException e) {
		//e.printStackTrace();
	//}
	
}
}
