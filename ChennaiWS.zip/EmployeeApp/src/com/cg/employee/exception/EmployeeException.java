package com.cg.employee.exception;

public class EmployeeException extends Exception {
	public EmployeeException() {
		super();
	}
	public EmployeeException(String message) {
		super(message);
	}
}
