package com.cg.cab.ui;
import java.time.LocalDate;
import java.util.Scanner;

import com.cg.cab.bean.CabRequest;
import com.cg.cab.exception.BookingException;
import com.cg.cab.service.BookingSeriviceIMPL;
import com.cg.cab.service.BookingService;

public class Client {
	Scanner sc=new Scanner(System.in);
	BookingService bs=new BookingSeriviceIMPL();
	public static void main(String[] args) {
		Client c=new Client();
		c.sc.useDelimiter("\n");
		
String option=null;
while(true) {
System.out.println("...................Booking Application....................");
System.out.println("1. Raise Cab request");
System.out.println("2. View cab request status");
System.out.println("3. Exit");
System.out.println("Enter your choice");
option=c.sc.nextLine();

switch(option) {
case "1":
	c.addRequest();
	break;
case "2":	c.viewRequest();
	break;
case "3":	System.exit(0);
	break;
	
default:
	System.out.println("Enter valid option within 1 and 3");
	break;
}
}

	}
	
	public void addRequest() {
		CabRequest request=new CabRequest();
/*		System.out.println("enter request Id");
		request.setRequestId(Integer.parseInt(sc.nextLine()));*/
		System.out.println("Customer name");
		request.setCustomerName(sc.nextLine());
		System.out.println("Enter phone num");
		request.setPhoneNum(sc.nextLine());
		//date will be automatically processed
		System.out.println("Enter pickup address");
		request.setPickUpAddr(sc.nextLine());
		System.out.println("Enter pincode");
		request.setPinCode(sc.nextLine());
		
		try {
			boolean result=bs.validateRequest(request);
			if(result) {
				request.setDateOfRequest(LocalDate.now());
				request.setStatus("Not Accepted");
				int ret=bs.addRequest(request);
				System.out.println("Request has been successfully registered. Your request ID is :"+ret);
			}
		}
		catch(BookingException ex) {
			System.out.println();
			System.err.println("an error occured: "+ex.getMessage());
			System.out.println();
		}
		
	}
	public void viewRequest() {
		System.out.println("enter request id");
		String id=sc.nextLine();
		try {
		int reqId=Integer.parseInt(id);
		CabRequest request=bs.geRequest(reqId);
		System.out.println("name of the customer: "+request.getCustomerName());
		System.out.println("Request status: "+request.getStatus());
		System.out.println("Cab num:"+request.getCabNum());
		System.out.println("pickup addr: "+request.getPickUpAddr());
		}
		catch(BookingException e) {
			System.out.println();
			System.err.println("An error occured: "+e.getMessage());
			System.out.println();
		}
		catch(Exception e) {
			System.out.println();
			e.printStackTrace();
			System.err.println("an error ocurred :"+e.getMessage());
		}
	}
}
