package com.cg.cab.service;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import com.cg.cab.bean.CabRequest;
import com.cg.cab.dao.BookingDAO;
import com.cg.cab.dao.BookingDAOimpl;
import com.cg.cab.exception.BookingException;


public class BookingSeriviceIMPL implements BookingService{
BookingDAO bookingDao=new BookingDAOimpl();
	

	@Override
	public boolean validateRequest(CabRequest request) throws BookingException {
		if(validateName(request.getCustomerName()) && validatePhone(request.getPhoneNum())) {
			return true;
		}
		else return false;
	}
	
	private boolean validateName(String name) throws BookingException{
		if(name.isEmpty() || name==null) {
			throw new BookingException("Customer nam cannot be empty");
		}
		else {
			if(!name.matches("[A-Z][A-Za-z]{2,}")) {
				throw new BookingException("Customer name should start with capital letter and should be of minimum 3 characters");
			}
		}
		return true;
		
	}
	private boolean validatePhone(String phone) throws BookingException{
		if(phone.isEmpty() || phone==null) {
			throw new BookingException("Phone num cannot be empty");
		}
		else {
			if(!phone.matches("\\d{10}")) {
				throw new BookingException("phone num should have 10 digits");
			}
		}
		return true;
	}

	@Override
	public int addRequest(CabRequest request) throws BookingException {
		try{
			FileInputStream fis=new FileInputStream("pincode.properties");
		Properties props=new Properties();
		props.load(fis);
		String cabNo=props.getProperty(request.getPinCode());
		if(cabNo!=null) {
			request.setCabNum(cabNo);
			request.setStatus("Accepted");
		
	}
		return bookingDao.addRequest(request);
}
	catch(FileNotFoundException e) {
		throw new BookingException(e.getMessage());
	}
	catch(IOException e) {
		throw new BookingException(e.getMessage());
		
	}

}

	@Override
	public CabRequest geRequest(int requestId) throws BookingException {
	
		return bookingDao.geRequest(requestId);
	}
	}
