package com.cg.cab.dao;

import com.cg.cab.bean.CabRequest;
import com.cg.cab.exception.BookingException;

public interface BookingDAO {
public int addRequest(CabRequest Request) throws BookingException;
public CabRequest geRequest(int requestId) throws BookingException;
}
