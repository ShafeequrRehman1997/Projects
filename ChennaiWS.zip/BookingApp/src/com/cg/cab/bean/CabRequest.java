package com.cg.cab.bean;
import java.time.LocalDate;


public class CabRequest {
private int requestId;
private String customerName;
private String phoneNum;
private LocalDate dateOfRequest;
private String status;
private String cabNum;
private String pickUpAddr;
private String pinCode;

public int getRequestId() {
	return requestId;
}
public void setRequestId(int requestId) {
	this.requestId = requestId;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getPhoneNum() {
	return phoneNum;
}
public void setPhoneNum(String phoneNum) {
	this.phoneNum = phoneNum;
}
public LocalDate getDateOfRequest() {
	return dateOfRequest;
}
public void setDateOfRequest(LocalDate dateOfRequest) {
	this.dateOfRequest = dateOfRequest;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getCabNum() {
	return cabNum;
}
public void setCabNum(String cabNum) {
	this.cabNum = cabNum;
}
public String getPickUpAddr() {
	return pickUpAddr;
}
public void setPickUpAddr(String pickUpAddr) {
	this.pickUpAddr = pickUpAddr;
}
public String getPinCode() {
	return pinCode;
}
public void setPinCode(String pinCode) {
	this.pinCode = pinCode;
}


}
