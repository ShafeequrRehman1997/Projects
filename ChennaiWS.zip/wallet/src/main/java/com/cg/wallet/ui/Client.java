package com.cg.wallet.ui;

import java.util.Scanner;

import com.cg.wallet.bean.Customer;
import com.cg.wallet.exception.BankException;
import com.cg.wallet.service.BankService;
import com.cg.wallet.service.BankServiceIMPL;
public class Client {
static Scanner sc=new Scanner(System.in);
 BankService bankService=new BankServiceIMPL();//priv WalletService walletservice=new WalletServiceImpl();
	public static void main(String[] args) {
		String option=null;
		
		Client c=new Client();
		while(true) {
			System.out.println("=============XYZ Banking System=============");
			System.out.println("1. Create account");
			System.out.println("2. Show balance");
			System.out.println("3. Deposit");
			System.out.println("4. withdraw");
			System.out.println("5. fund transfer");
			System.out.println("6. Print transactions");
			System.out.println("7. EXIT");
			
			System.out.println("choose an option");
			option=c.sc.nextLine();
			switch (option) {
			case "1":
						c.createAccount();
				break;
				
			case "2":
						c.showBalance();
				break;

			case "3":
						c.deposit();
				break;
				
			case "4":
						c.withdraw();
				break;
				
			case "5":	
						c.fundTransfer();
				break;
				
			case "6":
						c.printTransactions();
				break;
				
			case "7":
						System.exit(0);
				break;
				
			default:
						System.err.println("inavlid option,....choose from 1 to 7");
						System.out.println();
				break;
			}
		}

	}
		public void printTransactions() {
	
	}
		public void fundTransfer() {
	
		
	}
		public void withdraw() {
		
	}
		public void deposit() {

	}
		
		public void showBalance() {
	
			System.out.println("enter cust id");
			String id=sc.nextLine();
			

		try {
			//int cid=Integer.parseInt(id);
			Customer cus=bankService.showBalance(id);
			System.out.println(cus);
		}
		catch(Exception ex) {
			System.err.println("an error occured "+ex.getMessage());
		}
	}
		
		
	
		public void createAccount()  {
		Customer cus=new Customer();
		//System.out.println("Enter cust id");
		//String id=sc.nextLine();
							//String custId=Integer.parseInt(id);
		//cus.setId(Integer.parseInt(id));
				//emp.setId(Integer.parseInt(sc.nextLine()));
		System.out.println("Enter cust name");
		cus.setName(sc.nextLine());
		System.out.println("enter mobile");
		cus.setPhone(sc.nextLine());
		System.out.println("enter gender");
		cus.setGender(sc.nextLine());
		System.out.println("enter address");
		cus.setAddr(sc.nextLine());
		
		try {
			boolean result=bankService.validateCustomer(cus);
			if(result) {
				int ret= bankService.createAccount(cus);
				System.out.println("customer account with id "+ret+" created successfully");
			}
			//System.out.println("validated!");
		} catch (Exception exx) {                
			System.out.println();
			System.err.println("an error occured "+exx.getMessage());
			System.out.println();
		}
		
	}
}