package com.cg.wallet.bean;

public class Customer {
private String name;
private String gender;
private int age;
private String phone;
private int id;
private String addr;
/*private long accNo;
private String type;
private double balance;*/
//private int cId;
/*public long getAccNo() {
	return accNo;
}
public void setAccNo(long accNo) {
	this.accNo = accNo;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}*/


public Customer() {
	super();
}
public Customer(String name, String gender, int age, String phone, int id, String addr) {
	super();
	this.name = name;
	this.gender = gender;
	this.age = age;
	this.phone = phone;
	this.id = id;
	this.addr = addr;
}
@Override
public String toString() {
	return "Customer [name=" + name + ", gender=" + gender + ", age=" + age + ", phone=" + phone + ", id=" + id	+ ", addr=" + addr + "accNo=\" + accNo + \", type=\" + type + \", balance=\" + balance + \"]";
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getAddr() {
	return addr;
}
public void setAddr(String addr) {
	this.addr = addr;
}

}
