package com.cg.wallet.service;


import com.cg.wallet.bean.Customer;
import com.cg.wallet.dao.BankDAO;
import com.cg.wallet.dao.BankDAOimpl;
import com.cg.wallet.exception.BankException;

public class BankServiceIMPL implements BankService {
	BankDAO bankDao = new BankDAOimpl();
	@Override
	public boolean validateCustomer(Customer cus) throws BankException {
		
		if(validateName(cus.getName()) && validatePhone(cus.getPhone())) {
			return true;
		}
		else return false;
	}


	private boolean validatePhone(String phone) throws BankException {
	
			if(phone.isEmpty() || phone==null) {
				throw new BankException("employee mobile  cannot be empty, it is mandatory");
			}
			else {
				if(!phone.matches("\\d{10}")) {
					throw new BankException("mobile no. should contain 10 digits only");
				}
			}
			return true;
	}

	private boolean validateName(String name) throws BankException {
		if(name.isEmpty() || name==null) {
			throw new BankException("employee name cannot be empty");
		}
		else {
			if(!name.matches("[A-Z][A-Za-z]{2,}")) {    //if notmatches or doesn't matches 
				throw new BankException("Name should start with a capital letter followed by a minimum of 2 charcters");//then...Name should start....
			}
		}
		return true;
	}

	@Override
	public int createAccount(Customer cus) throws BankException {
		
		return bankDao.createAccount(cus);
	}

	public Customer showBalance(String id) throws BankException {

		return null;
	}


}
