package com.cg.wallet.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Optional;

import com.cg.wallet.bean.Customer;
import com.cg.wallet.db.BankDB;
import com.cg.wallet.exception.BankException;

public class BankDAOimpl implements BankDAO {
	static HashMap<Integer,Customer> bankMap=BankDB.getCustomerMap();
	String type=null;
	
	public BankDAOimpl()
	{
		
	}
	
	public BankDAOimpl(String type)
	{
		this.type=type;
	}

	@Override
	public int createAccount(Customer cus)throws BankException {
		

		try {
			if(bankMap.size()==0)
			{
				cus.setId(1001);
				cus.setAccNo(5001);
			}
		else {
			
				Optional<Integer> id=bankMap.keySet().stream().max((x,y)->x>y?1:x<y?-1:0);
				int reqid=id.get()+1;
				Collection<Customer> id2=bankMap.values();
				

			//int reqid=(int)(Math.random()*100)+1000;
			cus.setId(reqid);
		}
		bankMap.put(cus.getId(),cus);
		return cus.getId();
	}
	catch(Exception ex)
	{
		throw new BankException(ex.getMessage());
	}
	}
///////////////////////
	/*public Map<Integer,Bank> assignAccount(String type) throws BankException
	{
		int accno=0;
		try {
			Bank bank=new Bank();
			bank.setType(type);
			bank.setBalance(0);
			if(bankMap.size()==0)
			{	
				accno=5001;
				
			}
			else {
				Optional<Bank> id=bankMap.values();
				System.out.println("no:"+id.get());
				accno=id.getInt(1)+1;
				}
			bank.setAccno(accno);
			bankMap.put(bank.getCustomerId(),bank);
			return bankMap;
		}
		catch(Exception ex)
		{
			throw new BankException(ex.getMessage());

		}
		
		
	}*/
}