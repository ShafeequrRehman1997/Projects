package com.cg.wallet.dao;

import com.cg.wallet.bean.Customer;
import com.cg.wallet.exception.BankException;

public interface BankDAO {

	int createAccount(Customer cus) throws BankException;

}
