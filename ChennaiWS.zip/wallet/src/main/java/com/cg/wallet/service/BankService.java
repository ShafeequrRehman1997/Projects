package com.cg.wallet.service;

import com.cg.wallet.bean.Customer;
import com.cg.wallet.exception.BankException;

public interface BankService {

	public boolean validateCustomer(Customer cus) throws BankException;

	int createAccount(Customer cus) throws BankException;

	Customer showBalance(String id) throws BankException;
}
