package com.cg.wallet.db;

import java.util.HashMap;

//import com.cg.wallet.bean.Bank;
import com.cg.wallet.bean.Customer;


public class BankDB {
	private static HashMap<Integer, Customer> customerMap =new HashMap<Integer, Customer>();
	//private static HashMap<Integer, Bank> bankMap =new HashMap<Integer, Bank>();
	public static HashMap<Integer, Customer> getCustomerMap()
	{
		return customerMap;
	}
	
	
	
}
