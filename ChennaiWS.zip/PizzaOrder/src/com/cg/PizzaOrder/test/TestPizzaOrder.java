package com.cg.PizzaOrder.test;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

import com.cg.PizzaOrder.bean.Customer;
import com.cg.PizzaOrder.bean.PizzaOrder;
import com.cg.PizzaOrder.exception.PizzaException;
import com.cg.PizzaOrder.service.IPizzaOrderService;
import com.cg.PizzaOrder.service.PizzaOrderService;



	public class TestPizzaOrder {

		
		IPizzaOrderService service=new PizzaOrderService();

		@Test
		public void testPlaceOrder() throws PizzaException {
			double basePizzaPrice=350;
			double toppingPrice=85;
			Customer customer=new Customer("Hhgfg","Chennai","9999999999");
			double totalPrice=basePizzaPrice + toppingPrice;
			PizzaOrder pizza=new PizzaOrder(totalPrice);
			int id=service.placeOrder(customer,pizza);
			assertEquals(pizza.getOrderId(),id);
		/* service.placeOrder(customer,pizza)*/
		}
		
		@Test
		public void testGetOrder() throws PizzaException {
			double basePizzaPrice=350;
			double toppingPrice=85;
			Customer customer=new Customer("Jjsg","Cennai","9998999999");
			double totalPrice=basePizzaPrice + toppingPrice;
			PizzaOrder pizza=new PizzaOrder(totalPrice);
			int orderId=service.placeOrder(customer,pizza);
			int id=pizza.getOrderId();
			assertEquals(id,service.getOrderDetails(orderId).getOrderId());
		/* service.placeOrder(customer,pizza)*/
		
		}
		
	}
