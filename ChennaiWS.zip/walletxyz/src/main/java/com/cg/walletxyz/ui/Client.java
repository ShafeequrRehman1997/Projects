package com.cg.walletxyz.ui;

import java.util.Scanner;

import com.cg.walletxyz.bean.Customer;
import com.cg.walletxyz.bean.Transactions;
import com.cg.walletxyz.bean.Wallet;
import com.cg.walletxyz.dao.WalletDao;
import com.cg.walletxyz.dao.WalletDaoImpl;
import com.cg.walletxyz.exception.WalletException;
import com.cg.walletxyz.service.WalletService;
import com.cg.walletxyz.service.WalletServiceImpl;

public class Client {
	static Scanner sc=new Scanner(System.in);
	WalletService walletService=new WalletServiceImpl();
	public static void main(String[] args) {
		Client c=new Client();

		while(true)
		{
			System.out.println("===================XYZ Bank================");
			System.out.println("1. Create Account:");
			System.out.println("2. Show Balance:");
			System.out.println("3. Deposit:");
			System.out.println("4. Withdraw:");
			System.out.println("5. Fund Transfer:");
			System.out.println("6. Print Transactions:");
			System.out.println("7. EXIT");
			String choice=null;
			choice=sc.nextLine();
			
			switch(choice)
			{
			case "1":
				c.createAccount();
				break;
			case "2":
				c.showBalance();
				break;
			case "3":
				c.deposit();
				break;
			case "4":
				c.withdraw();
				break;
			case "5":
				c.fundTransfer();
				break;
			case "6":
				c.printTransactions();				
				break;
			case "7":
				System.exit(0);
				break;
			default:
				System.out.println("Invalid option selected!");
				break;
				
			}
		}	
	}
	public void printTransactions() {
		try {
			System.out.println("Enter account no.: ");
			String accno=sc.nextLine();
			Transactions transaction=walletService.printTransactions(accno);
			System.out.println(transaction);
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		
	}
	public void createAccount()
	{
		Customer customer=new Customer();
		System.out.println("Enter Customer name:");
		customer.setName(sc.nextLine());
		System.out.println("Enter customer age:");
		customer.setAge(Integer.parseInt(sc.nextLine()));
		System.out.println("Enter customer gender:");
		customer.setGender(sc.nextLine());
		System.out.println("Enter customer phone number");
		customer.setPhone(sc.nextLine());
		System.out.println("Enter address:");
		customer.setAddress(sc.nextLine());
try {
	boolean result=walletService.validateWallet(customer);
	if(result) {
		double initbalance=0;
		int ret=walletService.createAccount(customer);
		System.out.println("Customer with id "+ret+" added successfully");
		System.out.println("Enter account type:");
		Wallet wallet=new Wallet();
		String acType=sc.nextLine();
		wallet.setType(acType);
		wallet.setBalance(initbalance);
		WalletDao walletDao=new WalletDaoImpl();
		int accno=walletDao.assignAccount(acType);
		System.out.println("your acc no is: "+accno);
	}
}
catch(WalletException ex) {
	System.out.println();
	System.out.println("An error occurred"+ex.getMessage());
	System.out.println();
}
	}
	
	public void showBalance()
	{
		try {
		System.out.println("Enter account  number:");
		int accno=Integer.parseInt(sc.nextLine());
		double balance=walletService.showBalance(accno);
		System.out.println("Your account balance is: "+balance);
		}
		catch(Exception ex)
		{
			System.out.println("Error!"+ex.getMessage());
		}
	}
	
	public void deposit()
	{
		try {
			System.out.println("Enter account number:");
			int accno=Integer.parseInt(sc.nextLine());
			System.out.println("Enter the amount:");
			double amount=Double.parseDouble(sc.nextLine());

			double res=walletService.deposit(accno,amount);
			if(res!=-1)
			{
				System.out.println("Amount deposited successfully!");
			}
			else
			{
				System.err.println("Could not deposit amount.!");
			}
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
	}
	
	public void withdraw() {
		try {
			System.out.println("Enter account number:");
			int accno=Integer.parseInt(sc.nextLine());
			System.out.println("Enter the amount:");
			int amount=Integer.parseInt(sc.nextLine());

			double res=walletService.withdraw(accno,amount);
			if(res!=0)
			{
				System.out.println("Amount withdrawn successfully!");
			}
			else
			{
				System.err.println("Could not withdraw amount.!");
			}
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
	}
	public void fundTransfer() {
		try {
			System.out.println("Enter from account :");
			int fromAccno=Integer.parseInt(sc.nextLine());
			System.out.println("Enter to account :");
			int toAccno=Integer.parseInt(sc.nextLine());
			System.out.println("Enter the amount:");
			int amount=Integer.parseInt(sc.nextLine());

			double res=walletService.fundTransfer(fromAccno,toAccno,amount);
			if(res!=0)
			{
				System.out.println("Amount transferred successfully!");
			}
			else
			{
				System.err.println("Could not transfer amount.!");
			}
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
	}

	}
