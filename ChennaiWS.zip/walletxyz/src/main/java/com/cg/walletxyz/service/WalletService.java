package com.cg.walletxyz.service;
import com.cg.walletxyz.bean.Customer;
import com.cg.walletxyz.bean.Transactions;
import com.cg.walletxyz.bean.Wallet;
import com.cg.walletxyz.exception.WalletException;
public interface WalletService {
	boolean validateWallet(Customer customer) throws WalletException;
	public int createAccount(Customer customer) throws WalletException;
	public double showBalance(int accno) throws WalletException;
	public double deposit(int accno,double amount) throws WalletException;
	public int withdraw(int accno,double amount) throws WalletException;
	public int fundTransfer(int faccno,int taccno,double amount) throws WalletException;
	public Transactions printTransactions(String accno) throws WalletException;
}
