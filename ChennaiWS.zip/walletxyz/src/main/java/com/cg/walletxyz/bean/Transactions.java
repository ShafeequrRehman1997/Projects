package com.cg.walletxyz.bean;

public class Transactions {
private String accNo;
private String transactionType;
private double amount;
private double bal;
public String getAccNo() {
	return accNo;
}
public void setAccNo(String accNo) {
	this.accNo = accNo;
}
public String getTransactionType() {
	return transactionType;
}
public void setTransactionType(String transactionType) {
	this.transactionType = transactionType;
}
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}
public double getBal() {
	return bal;
}
public void setBal(double bal) {
	this.bal = bal;
}
@Override
public String toString() {
	return "Transactions [accNo=" + accNo + ", transactionType=" + transactionType + ", amount=" + amount + ", bal="+ bal + "]";
}

}
