package com.cg.walletxyz.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.walletxyz.bean.Wallet;
import com.cg.walletxyz.dao.WalletDaoImpl;
import com.cg.walletxyz.exception.WalletException;
import com.cg.walletxyz.service.WalletServiceImpl;

import junit.framework.Assert;
import junit.framework.TestCase;

public class WalletServiceImplTest extends TestCase {


	@Test
	public void testValidateName() throws WalletException{
		WalletServiceImpl w=new WalletServiceImpl();
		Assert.assertEquals(true, w.validateName("Shafeeq"));
	}
	@Test
	public void testValidatePhone() throws WalletException{
		WalletServiceImpl w=new WalletServiceImpl();
		Assert.assertEquals(true, w.validatePhone("9999999999"));
	}
	@Test
	public void testCreateAccount(){
		WalletDaoImpl w=new WalletDaoImpl();
		Wallet a=new Wallet();
		Assert.assertEquals(5001,5001);
	}
	@Test
	public void testValidateNamefail(){
		WalletServiceImpl w=new WalletServiceImpl();
		try{
			Assert.assertEquals(false, w.validateName("rahul"));
		}catch(WalletException e) {
			
		}
	}
	@Test
	public void testValidatePhonefail(){
		WalletServiceImpl w=new WalletServiceImpl();
		try{
			Assert.assertEquals(false, w.validatePhone("8888888998888"));
		}catch(WalletException e) {
			
		}
	}
	
	
}
