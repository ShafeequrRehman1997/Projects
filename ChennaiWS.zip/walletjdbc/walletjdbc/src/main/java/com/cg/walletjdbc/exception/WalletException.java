package com.cg.walletjdbc.exception;

public class WalletException extends Exception{

	public WalletException() {
		super();
	}
	public WalletException(String message) {
		super(message);
	}
	
}
