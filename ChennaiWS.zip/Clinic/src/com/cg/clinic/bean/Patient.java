package com.cg.clinic.bean;

import java.time.LocalDate;

public class Patient {
private int patientId;
private String name;
private int age;
private String phone;
private String description;
private LocalDate consDate;

public Patient() {
	super();
}



@Override
public String toString() {
	return "Patient [patientId=" + patientId + ", name=" + name + ", age=" + age + ", phone=" + phone + ", description="
			+ description + ", consDate=" + consDate + "]";
}



public Patient(int patientId, String name, int age, String phone, String description, LocalDate consDate) {
	super();
	this.patientId = patientId;
	this.name = name;
	this.age = age;
	this.phone = phone;
	this.description = description;
	this.consDate = consDate;
}
public int getPatientId() {
	return patientId;
}
public void setPatientId(int patientId) {
	this.patientId = patientId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public LocalDate getConsDate() {
	return consDate;
}
public void setConsDate(LocalDate consDate) {
	this.consDate = consDate;
}


}
