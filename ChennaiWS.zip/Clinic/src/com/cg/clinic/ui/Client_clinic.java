package com.cg.clinic.ui;

import java.time.LocalDate;
import java.util.Scanner;

/*import com.cg.cab.service.BookingSeriviceIMPL;
import com.cg.cab.service.BookingService;*/
import com.cg.clinic.bean.Patient;
import com.cg.clinic.exception.PatientException;
import com.cg.clinic.service.PatientService;
import com.cg.clinic.service.PatientServiceIMPL;

public class Client_clinic {
Scanner sc=new Scanner(System.in);
PatientService bs=new PatientServiceIMPL();
	public static void main(String[] args) {
		String option=null;
		
		Client_clinic c=new Client_clinic();
		
		while(true) {
			System.out.println("=============Clinic software application=============");
			System.out.println("1. Add patient info");
			System.out.println("2. Search patient by Id");
			System.out.println("3. Exit");
			System.out.println();
			System.out.println("Choose an option");
			
			option=c.sc.nextLine();
			switch(option) {
			case "1":	c.addPatientINFO();
						break;
			case "2":	c.searchPatientById();
						break;
			case "3":	System.exit(0);
						break;
			default:	System.err.println("inavlid option,....choose from 1 to 3");
						System.out.println();
						break;
			}
		}
	}
			
		public void addPatientINFO() {
			Patient request=new Patient();

			System.out.println("patient name");
			request.setName(sc.nextLine());
			System.out.println("enter age");
			request.setAge(sc.nextInt());
			System.out.println("Enter phone num");
			request.setPhone(sc.nextLine());
			//date will be automatically processed
			System.out.println("Enter description");
			request.setDescription(sc.nextLine());
	
	try {
		boolean result=bs.validateRequest(request);
		if(result) {
			request.setConsDate(LocalDate.now());
			//request.setStatus("Not Accepted");
			int ret=bs.addRequest(request);
			System.out.println("Request has been successfully registered. Your request ID is :"+ret);
		}
		catch (PatientException e) {	
	
	}

}
