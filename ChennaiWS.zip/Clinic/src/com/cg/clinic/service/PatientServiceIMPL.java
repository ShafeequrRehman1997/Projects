package com.cg.clinic.service;

import com.cg.cab.dao.BookingDAO;
import com.cg.cab.dao.BookingDAOimpl;
import com.cg.cab.exception.BookingException;
import com.cg.clinic.dao.PatientDAO;

public class PatientServiceIMPL implements PatientService{
	PatientDAO pDao=new PatientDAOimpl();

	private boolean validateName(String name) throws PatientException{
		if(name.isEmpty() || name==null) {
			throw new PatientException("Patient name cannot be empty");
		}
		else {
			if(!name.matches("[A-Z][A-Za-z]{2,}")) {
				throw new PatientException("patient name should start with capital letter and should be of minimum 3 characters");
			}
		}
		return true;
		
	}

}
