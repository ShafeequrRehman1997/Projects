package com.cg.clinic.service;
import com.cg.clinic.bean.*;
import com.cg.clinic.exception.PatientException;
public interface PatientService {

	boolean validateRequest(Patient request) throws PatientException;

	public int addRequest(Patient request) throws PatientException;
	

}
