package com.cg.clinic.dao;
import java.util.*;

/*import com.cg.cab.bean.CabRequest;
import com.cg.cab.exception.BookingException;*/
import com.cg.clinic.bean.*;
import com.cg.clinic.exception.PatientException;
public interface PatientDAO {
	public int addRequest(CabRequest Request) throws BookingException;
	public CabRequest geRequest(int requestId) throws BookingException;
}
