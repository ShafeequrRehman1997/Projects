package com.cg.clinic.dao;

public class PatientDAOimpl implements PatientDAO {

	public static void main(String[] args) {
		

	}


	

}
