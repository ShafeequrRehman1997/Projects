package com.cg.clinic.db;

import java.util.HashMap;

import com.cg.clinic.bean.Patient;
import com.cg.clinic.bean.Patient;

public class PatientDB {
	private static HashMap<Integer, Patient> patientMap =new HashMap<Integer, Patient>();
	public static HashMap<Integer, Patient> setPatientMap(HashMap<Integer, Patient> patientMap) {
		return patientMap;
		

}
}
