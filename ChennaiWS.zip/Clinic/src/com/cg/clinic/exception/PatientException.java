package com.cg.clinic.exception;

public class PatientException extends Exception {
	public PatientException() {
	super();
}
	public PatientException(String message) {
	super(message);
}
}
