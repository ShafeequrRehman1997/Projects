package com.cg.productmgmt.dao;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.cg.productmgmt.exception.ProductException;

public class ProductDAO implements IProductDAO {
static Map<String,String> prodDetails;
static Map<String, Integer> salesDetails;

static {
	prodDetails=new HashMap<>();
	prodDetails.put("lux",  "soap");
	prodDetails.put("colgate", "paste");
	prodDetails.put("pears",  "soap");
	prodDetails.put("sony",  "electronics");
	prodDetails.put("samsung",  "electronics");
	prodDetails.put("facepack",  "cosmatics");
	prodDetails.put("facecream",  "cosmatics");
	
	salesDetails=new HashMap<>();
	salesDetails.put("lux", 100);
	salesDetails.put("colgate", 50);
	salesDetails.put("pears", 70);
	salesDetails.put("sony", 10000);
	salesDetails.put("samsung", 23000);
	salesDetails.put("facepack", 100);
	salesDetails.put("facecream", 60);
}

@Override
public int updateProducts(String category, int hike) throws ProductException {
	Set<String> products=new HashSet<String>();
	Set<String> keys=prodDetails.keySet();
	String value = null;
	 int nePrice=0;
	 int updated=0;
	 boolean isUpdated=false;
	 for(String key:keys) {
		 value=prodDetails.get(key);
		 if(value.equals(category)) {
			 products.add(key);
		 }
	 }
	 Set<String> keySales=salesDetails.keySet();
	 for(String sale:keySales) {
		if(products.contains(sale))
		{
			nePrice=salesDetails.get(sale);
			nePrice+=hike;
			salesDetails.put(sale, nePrice);
			updated=1;
		}
	 }
	return updated;
}

@Override
public Map<String, Integer> getProductDetails() throws ProductException {
	
	return salesDetails;
}

 public boolean validateCategory(String category) {
	String s=new String(category);
	if(prodDetails.containsValue(category)) {
		return true;
	}
	else return false;
}
}
