package com.cg.productmgmt.service;

import java.util.Map;


import com.cg.productmgmt.bean.Product;
import com.cg.productmgmt.dao.IProductDAO;
import com.cg.productmgmt.dao.ProductDAO;
import com.cg.productmgmt.exception.ProductException;

public class ProductService implements IProductService{
IProductDAO productdao=new ProductDAO();

@Override
public boolean validateUpdate(Product product) throws ProductException {
	if(validateCategory(product.getCategory()) && validateRate(product.getRate())) {
		return true;
	}
	else return false;
}



	private boolean validateRate(int rate) throws ProductException {
if(rate<0) {
	throw new ProductException("Hike rate must be greater than zero");	
}
else return true;
}




	public boolean validateCategory(String category) throws ProductException{
	// TODO Auto-generated method stub
		IProductDAO  dao=new ProductDAO();
			
		if(!dao.validateCategory(category)) {
			throw new ProductException("category cannot be empty");
		}
		return true;
}





	@Override
	public int updateProducts(String Category, int hike) throws ProductException {
		
		return productdao.updateProducts(Category, hike);
	}

	@Override
	public Map<String, Integer> getProductDetails() throws ProductException {
		
		return productdao.getProductDetails();
	}

}
