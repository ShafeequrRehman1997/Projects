package com.cg.productmgmt.ui;

import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.cg.productmgmt.bean.Product;
import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.service.IProductService;
import com.cg.productmgmt.service.ProductService;

public class Client {
	Scanner sc=new Scanner(System.in);	
	IProductService productService=new ProductService();
	public static void main(String[] args) {
		String choice=null;
		
		Client c=new Client();
		while(true) {
			System.out.println("=============Product Management System=============");
			System.out.println("1. Update Product Price");
			System.out.println("2. Display Product list");
			System.out.println("3. EXIT");
			
			
			System.out.println("select your choice");
			choice=c.sc.nextLine();
			switch (choice) {
			case "1":
						c.updateProducts();
				break;
				
			case "2":
						c.displayProdlist();
						
				break;

				
			case "3":
						System.exit(0);
				break;

				
			default:
						System.out.println();
				break;
			}
		}

	}

	public void updateProducts() {
		System.out.println("enter product category:");
		String category=sc.nextLine();
		System.out.println("enter hike rate:");
		int rate=Integer.parseInt(sc.nextLine());
		Product product=new Product(category,rate);
		
		try {
			if(productService.validateUpdate(product))
			{
				if(productService.updateProducts(category, rate)!=-1)
				{ 
					System.out.println("product price has been successfully updated");
				}
			}
				
			
			}
			catch(ProductException exc) {
				System.err.println(exc.getMessage());
			}
		
		
	}
	
	
	
	
	public void displayProdlist() {
		try {
		Map<String, Integer> productDetails=productService.getProductDetails();
		Set set=productDetails.entrySet();
		set.stream().forEach(System.out::println);
	}
		catch(ProductException ex) {
			System.out.println(ex.getMessage());
		}
	}
}


