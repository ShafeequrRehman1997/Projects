package com.cg.productmgmt.bean;

public class Product {
private String category;
private String name;
private int rate;
private double price;

public String getCategory() {
	return category;
}
public void setCategory(String category) {
	this.category = category;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getRate() {
	return rate;
}
public void setRate(int rate) {
	this.rate = rate;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
@Override
public String toString() {
	return "Product [category=" + category + ", name=" + name + ", rate=" + rate + ", price=" + price + "]";
}
public Product(String category, String name, int rate, double price) {
	super();
	this.category = category;
	this.name = name;
	this.rate = rate;
	this.price = price;
}
public Product(String category, int rate) {
	this.category=category;
	this.rate=rate;
}

}
/*public String getCategory() {
	return category;
}
public void setCategory(String category) {
	this.category = category;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public Product() {
	super();
}
public Product(String category, String name, double price) {
	super();
	this.category = category;
	this.name = name;
	this.price = price;
}
@Override
public String toString() {
	return "Product [category=" + category + ", name=" + name + ", price=" + price + "]";
}
}*/
