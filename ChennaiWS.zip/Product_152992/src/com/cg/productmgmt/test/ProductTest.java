package com.cg.productmgmt.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Map;

import org.junit.jupiter.api.Test;

import com.cg.productmgmt.dao.IProductDAO;
import com.cg.productmgmt.dao.ProductDAO;
import com.cg.productmgmt.exception.ProductException;

class ProductTest {
	IProductDAO pdao=new ProductDAO();

	
@Test
public void testUpdateProducts() {
	try {
		int hike=55;
		String cat="electronics";
		int p=pdao.updateProducts(cat, hike);
	}catch(ProductException e) {
		System.out.println(e.getLocalizedMessage());
		
	}
}
@Test
public void testDisplayProdList() {
	try {
		Map<String,Integer> p=pdao.getProductDetails();
		
	}catch(ProductException e) {
		System.out.println(e.getLocalizedMessage());
		
	}
}
}
