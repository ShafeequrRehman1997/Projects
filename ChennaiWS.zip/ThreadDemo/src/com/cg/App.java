package com.cg;

import java.util.Scanner;

//Inter thread communication

public class App{
	public void produce() throws InterruptedException {
		synchronized (this) {
			
			System.out.println("Producer running....");
			wait();
			System.out.println("Producer resumed.....");
		}
	}
	public void consume() throws InterruptedException{
		Thread.sleep(1000);
		synchronized (this) {
			System.out.println("Consumer started....");
			Scanner s=new Scanner(System.in);
			System.out.println("waiting for return key....");
			s.nextLine();
			System.out.println("Return key pressed...");
			notify();
			Thread.sleep(2000);
		}
	}
}






















/*class Counter{
	int count;

public synchronized void increment() {
	
	for(int i=0;i<=10000;i++) {
		count++;
	}
}
}

public class App extends Thread{
	public static void main(String[] args) {
	Counter c=new Counter();

Thread t1=new Thread(new Runnable() {
	@Override
	
	public void run() {
		c.increment();
	}
});
Thread t2=new Thread(new Runnable() {
	@Override
	
	public void run() {
		c.increment();
	}
});
t1.start();
t2.start();
System.out.println(c.count);
}
}*/

/*	
//method1
public class App implements Runnable {
		
	public static void main(String[] args) throws InterruptedException {

		System.out.println("Main starts");
		DemoClass d=new DemoClass();
		Thread t1=new Thread(d);//(d,"First") see below at getNmae comment
		Thread t2=new Thread(d);
		t1.setPriority(5);//default//getPriority to get prio..
		t1.start();.println("main ends");
		System.out.println(t1.isAlive());
		System.out.println(t2.isAlive());

		t2.start();
		//t1.join();
		t1.join(6000);//after 6 sec it will show main ends no matter what
		System.out.println(t1.isAlive());
		System.out.println(t2.isAlive());
		System.out
	}
}

class DemoClass implements Runnable{
	public void run() {
	// TODO Auto-generated method stub
	for(int i=0;i<=10;i++) {
		System.out.println(i+" : "+Thread.currentThread().getName());//getName()...0,1 here
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//to avoid this long times multithreading can be used
		}
	
	}
}
	
	}



//method2
public class App extends Thread {
	

	@Override
	public void run() {
		for(int i=0;i<=10;i++) {
			System.out.println(i);
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				//to avoid this long times multithreading can be used
			}
		}
		
	}
	public static void main(String[] args) {
		//single threaded appn
		System.out.println("Main starts");
		App a=new App();
		App b=new App();
		a.start();
		b.start();
		
		System.out.println("main ends");

	}
}



/////////////////////implementing runnable is the best method than extending a thread class//remember there were 2 methods for creating a thread(java)
*/