package com.cg;
//import java.io.*;
import java.io.IOException;
import java.io.Reader;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
public class FileDemo {

	public static void main(String[] args) throws IOException {
		
	//file input stream example
/*		FileInputStream fis=new FileInputStream("d:/msr_25_6_1.txt");
	//table 17.3 and check all such tables
	int c;
	while((c=fis.read())!=-1) {
		System.out.print((char)c);
	}
	//without while
	byte[] buffer=new byte[fis.available()];
	fis.read(buffer,3,9);			//gives 3 spaces and starts till 9th character
	String str=new String(buffer);
	System.out.println(str);
	fis.close();
	*/
	
		FileInputStream fis=new FileInputStream("d:/msr_25_6_1.txt");
		FileOutputStream fos=new FileOutputStream("d:/msr_25_6_1_dup.txt");
		BufferedOutputStream bos=new BufferedOutputStream(fos);
		int c;
		while((c=fis.read())!=-1) {
			
			bos.write(c);
		}
		bos.flush();
		
		while((c=fis.read())!=-1) {
			System.out.print((char)c);
			fos.write(c);
		}
	System.out.println("Done!!File copied");
		//without while
		byte[] buffer=new byte[fis.available()];
		fis.read(buffer);
		fos.write(buffer);
		fis.close();
		fos.close();
		
		/*
		FileOutputStream fos=new FileOutputStream("d:/msr_25_6_1.txt");
		DataOutputStream out=new DataOutputStream(fos);
		int i=10;
		double d=12.34;
		boolean b=false;
		String s="hiiiii";
		out.writeDouble(d);
		out.writeBoolean(b);
		out.writeUTF(s);
		System.out.println("file written...");
		fos.close();*/
		
		//gave output........ @(�z�G�  hiiiii in msr_25_6_1.txt

		
/*		FileInputStream fis=new FileInputStream("d:/msr_25_6_1.txt");
		DataInputStream dis=new DataInputStream(fis);
		int i=dis.readInt();
		double d=dis.readDouble();
		boolean b=dis.readBoolean();
		String s=dis.readUTF();
		
		System.out.println(i);
		System.out.println(d);
		System.out.println(b);
		System.out.println(s);
		fis.close();*/
		
		/*System.out.println("enter something");
		int c;
		StringBuffer sb=new StringBuffer();
		while((c=System.in.read())!='\n') {
			sb.append((char)c);
		}
		System.out.println("you entered:"+sb);*/
		

	}

}