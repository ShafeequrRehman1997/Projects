import com.cg.App;
public class App2_InterThreadCommn {

	
	public static void main(String[] args) {
		App a=new App();
		Thread t1=new Thread(new Runnable() {
			
			@Override
			public void run() {
			try {
				a.produce();
			}                                                                                                                                                                                                                                                                                                                                                              
			catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
				
			
		});
Thread t2=new Thread(new Runnable() {
			
			@Override
			public void run() {
			try {
				a.consume();
			}
			catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
				
			
		});
		t1.start();
		t2.start();

	}

}
